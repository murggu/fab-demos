import json
import os
import uuid

import msal
from msal_extensions import (
    FilePersistence,
    PersistedTokenCache,
    build_encrypted_persistence,
)

from fabric_cli.core import fab_constant as con
from fabric_cli.core import fab_logger
from fabric_cli.core import fab_state_config as config
from fabric_cli.core.fab_exceptions import FabricCLIError
from fabric_cli.core.fab_hiearchy import Tenant
from fabric_cli.utils import fab_ui as utils_ui

# https://msal-python.readthedocs.io/en/latest/


def singleton(class_):
    instances = {}

    def getinstance(*args, **kwargs):
        if class_ not in instances:
            instances[class_] = class_(*args, **kwargs)
        return instances[class_]

    return getinstance


@singleton
class FabAuth:
    def __init__(self):
        # Auth file path
        self.auth_file = os.path.join(config.config_location(), "auth.json")
        self.cache_file = os.path.join(config.config_location(), "cache.bin")

        # Reset the auth info
        self.app: msal.ClientApplication = None
        self._auth_info = {}

        # Load the auth info and environment variables
        self._load_auth()
        self._load_env()

    def _save_auth(self):
        with open(self.auth_file, "w") as file:
            file.write(json.dumps(self._get_auth_info()))

    def _load_auth(self):
        if os.path.exists(self.auth_file) and os.stat(self.auth_file).st_size != 0:
            with open(self.auth_file, "r") as file:
                self._auth_info = json.load(file)
        else:
            self._auth_info = {
                con.FAB_AUTHORITY: con.AUTH_DEFAULT_AUTHORITY,
            }

    def _load_env(self):
        # Check if the environment variables are set
        # Removed usage of user tokens, need to see if this is still needed and if so, how to implement it
        if "FAB_TENANT_ID" in os.environ:
            tenant_id = os.environ["FAB_TENANT_ID"]
            self._verify_valid_guid_parameter(tenant_id, "FAB_TENANT_ID")
            self.set_tenant(tenant_id)

        if "FAB_SPN_CLIENT_ID" in os.environ and "FAB_SPN_CLIENT_SECRET" in os.environ:
            client_id = os.environ["FAB_SPN_CLIENT_ID"]
            self._verify_valid_guid_parameter(client_id, "FAB_SPN_CLIENT_ID")
            self.set_spn(
                os.environ["FAB_SPN_CLIENT_ID"],
                os.environ["FAB_SPN_CLIENT_SECRET"],
            )
        elif "FAB_SPN_CLIENT_ID" in os.environ or "FAB_SPN_CLIENT_SECRET" in os.environ:
            raise FabricCLIError(
                "Both FAB_SPN_CLIENT_ID and FAB_SPN_CLIENT_SECRET should be set",
                status_code=con.ERROR_AUTHENTICATION_FAILED,
            )

    def _get_auth_property(self, key):
        return self._auth_info.get(key, None)

    def _get_auth_info(self):
        return self._auth_info

    def _set_auth_property(self, key, value):
        self._auth_info[key] = value
        self._save_auth()

    def _set_auth_properties(self, properties: dict):
        self._auth_info.update(properties)
        self._save_auth()

    def _get_persistence(self):
        persistence = None
        try:
            persistence = build_encrypted_persistence(self.cache_file)
        except Exception as e:
            fab_logger.log_debug(f"Error using encrypted cache: {e}")

            if config.get_config(con.FAB_ENCRYPTION_FALLBACK_ENABLED) == "true":
                # Fallback to non-encrypted file-based token cache
                persistence = FilePersistence(self.cache_file)
            else:
                raise FabricCLIError(
                    "Encrypted cache error. Enable plaintext auth token fallback with 'config set encryption_fallback_enabled true'",
                    status_code=con.ERROR_AUTHENTICATION_FAILED,
                )

        return persistence

    def _get_app(self) -> msal.ClientApplication:
        if self.app is None:
            persistence = self._get_persistence()
            self.cache = PersistedTokenCache(persistence)

            if self.get_auth_mode() == "service_principal":
                self.app = msal.ConfidentialClientApplication(
                    client_id=self._get_auth_property(con.FAB_SPN_CLIENT_ID),
                    authority=self._get_auth_property(con.FAB_AUTHORITY),
                    token_cache=self.cache,
                )
                self._set_auth_properties(
                    {
                        con.FAB_AUTH_MODE: "service_principal",
                    }
                )
            else:
                # Load the cache into the MSAL application
                self.app = msal.PublicClientApplication(
                    client_id=con.AUTH_DEFAULT_CLIENT_ID,
                    authority=self._get_auth_property(con.FAB_AUTHORITY),
                    token_cache=self.cache,
                )
                self._set_auth_properties(
                    {
                        con.FAB_AUTH_MODE: "user",
                    }
                )
        return self.app

    def _get_access_token_from_env_vars_if_exist(self, scope):
        if "FAB_TOKEN" in os.environ and "FAB_TOKEN_ONELAKE" in os.environ:
            match scope:
                case con.SCOPE_FABRIC_DEFAULT:
                    return os.environ["FAB_TOKEN"]
                case con.SCOPE_ONELAKE_DEFAULT:
                    return os.environ["FAB_TOKEN_ONELAKE"]
                case con.SCOPE_AZURE_DEFAULT:
                    if "FAB_TOKEN_AZURE" in os.environ:
                        return os.environ["FAB_TOKEN_AZURE"]
                    else:
                        raise FabricCLIError(
                            f"You must set FAB_TOKEN_ONELAKE for operations against Azure APIs.",
                            status_code=con.ERROR_AUTHENTICATION_FAILED,
                        )
                case _:
                    raise FabricCLIError(
                        f"Invalid scope: {scope}",
                        status_code=con.ERROR_AUTHENTICATION_FAILED,
                    )

        elif "FAB_TOKEN" in os.environ or "FAB_TOKEN_ONELAKE" in os.environ:
            raise FabricCLIError(
                "Both FAB_TOKEN and FAB_TOKEN_ONELAKE should be set",
                status_code=con.ERROR_AUTHENTICATION_FAILED,
            )

        return None

    def get_tenant(self):
        return Tenant(
            name=self.get_tenant_name(),
            id=self.get_tenant_id(),
        )

    def get_tenant_name(self):
        # TODO: Get the tenant name from the tenant ID
        return "Unknown"

    def get_tenant_id(self):
        return self._get_auth_property(con.FAB_TENANT_ID)

    def get_auth_mode(self):
        return self._get_auth_property(con.FAB_AUTH_MODE)

    def set_access_mode(self, mode):
        if mode not in con.AUTH_KEYS[con.FAB_AUTH_MODE]:
            raise FabricCLIError(
                f"Invalid access mode: {mode}. Allowed values are: {con.AUTH_KEYS[con.FAB_AUTH_MODE]}",
                status_code=con.ERROR_AUTHENTICATION_FAILED,
            )
        if mode != self.get_auth_mode():
            self.logout()
        self._set_auth_property(con.FAB_AUTH_MODE, mode)

    def set_tenant(self, tenant_id):
        if tenant_id is not None:
            current_tenant_id = self.get_tenant_id()
            if current_tenant_id is not None and current_tenant_id != tenant_id:
                fab_logger.log_warning(
                    f"Tenant ID already set to {current_tenant_id}."
                    + f" Logout done and Tenant ID set to {tenant_id}."
                )
                self.logout()

            _authority = f"{con.AUTH_TENANT_AUTHORITY}{tenant_id}"
            self._set_auth_properties(
                {
                    con.FAB_TENANT_ID: tenant_id,
                    con.FAB_AUTHORITY: _authority,
                }
            )

    def set_spn(self, client_id, client_credential):
        persistence = self._get_persistence()
        self.cache = PersistedTokenCache(persistence)

        self.app = msal.ConfidentialClientApplication(
            client_id=client_id,
            client_credential=client_credential,
            authority=self._get_auth_property(con.FAB_AUTHORITY),
            token_cache=self.cache,
        )
        # if the client ID and secret are set and are different, then clear the existing tokens
        if (
            self._get_auth_property(con.FAB_SPN_CLIENT_ID) is not None
            and self._get_auth_property(con.FAB_SPN_CLIENT_ID) != client_id
        ):
            fab_logger.log_warning(
                f"Client ID already set to {self._get_auth_property(con.FAB_SPN_CLIENT_ID)}. Overwriting with {client_id} and clearing the existing auth tokens"
            )
            self.logout()
        self._set_auth_properties(
            {
                con.FAB_SPN_CLIENT_ID: client_id,
                con.FAB_SPN_CLIENT_SECRET: client_credential,
                con.FAB_AUTH_MODE: "service_principal",
            }
        )

    def print_auth_info(self):
        utils_ui.print_grey(json.dumps(self._get_auth_info(), indent=2))

    def _is_token_defined(self, scope):
        match scope:
            case con.SCOPE_FABRIC_DEFAULT:
                return con.FAB_TOKEN in self._get_auth_info()
            case con.SCOPE_ONELAKE_DEFAULT:
                return con.FAB_TOKEN_ONELAKE in self._get_auth_info()
            case con.SCOPE_AZURE_DEFAULT:
                return con.FAB_TOKEN_AZURE in self._get_auth_info()
            case _:
                raise FabricCLIError(
                    f"Invalid scope: {scope}",
                    status_code=con.ERROR_AUTHENTICATION_FAILED,
                )

    def get_access_token(self, scope, interactive_renew=True) -> str:
        if self._get_auth_property(con.FAB_AUTH_MODE) == "service_principal":
            token = self._get_app().acquire_token_for_client(scopes=scope)

            if token is None:
                return ""

            return token.get("access_token")

        # try to get the token from the environment variable
        env_var_token = self._get_access_token_from_env_vars_if_exist(scope)
        if env_var_token:
            return env_var_token

        accounts = self._get_app().get_accounts()
        account = None
        if accounts:
            account = accounts[0]
        token = self._get_app().acquire_token_silent(scopes=scope, account=account)

        if token is None and interactive_renew:
            token = self._get_app().acquire_token_interactive(
                scopes=scope, prompt="select_account"
            )
            self.set_tenant(token.get("id_token_claims")["tid"])

        if token is None:
            return ""

        return token.get("access_token")

    def logout(self):
        self._auth_info = {
            con.FAB_AUTHORITY: con.AUTH_DEFAULT_AUTHORITY,
        }
        self.app = None

        if os.path.exists(self.cache_file):
            os.remove(self.cache_file)

        self._save_auth()

        # Reset to default values
        config.set_config(con.FAB_CACHE_ENABLED,
                          con.CONFIG_DEFAULT_VALUES[con.FAB_CACHE_ENABLED])
        config.set_config(con.FAB_DEBUG_ENABLED,
                          con.CONFIG_DEFAULT_VALUES[con.FAB_DEBUG_ENABLED])
        config.set_config(con.FAB_SHOW_HIDDEN,
                          con.CONFIG_DEFAULT_VALUES[con.FAB_SHOW_HIDDEN])
        config.set_config(con.FAB_JOB_CANCEL_ONTIMEOUT,
                          con.CONFIG_DEFAULT_VALUES[con.FAB_JOB_CANCEL_ONTIMEOUT])
        config.set_config(con.FAB_DEFAULT_OPEN_EXPERIENCE,
                          con.CONFIG_DEFAULT_VALUES[con.FAB_DEFAULT_OPEN_EXPERIENCE])

        # Reset settings
        config.set_config(con.FAB_LOCAL_DEFINITION_LABELS, "")
        config.set_config(con.FAB_DEFAULT_CAPACITY, "")
        config.set_config(con.FAB_DEFAULT_CAPACITY_ID, "")

        # Reset Azure settings
        config.set_config(con.FAB_DEFAULT_AZ_SUBSCRIPTION_ID, "")
        config.set_config(con.FAB_DEFAULT_AZ_ADMIN, "")
        config.set_config(con.FAB_DEFAULT_AZ_RESOURCE_GROUP, "")
        config.set_config(con.FAB_DEFAULT_AZ_LOCATION, "")

    @staticmethod
    def _verify_valid_guid_parameter(parameter_value, parameter_name):
        try:
            uuid.UUID(parameter_value)
        except ValueError:
            raise FabricCLIError(
                f"{parameter_name} must be a valid GUID",
                status_code=con.ERROR_AUTHENTICATION_FAILED,
            )
