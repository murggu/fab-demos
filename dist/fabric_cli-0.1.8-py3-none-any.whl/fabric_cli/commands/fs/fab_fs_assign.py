import json
from argparse import Namespace

from fabric_cli.client import fab_api_domain as domain_api
from fabric_cli.client import fab_api_workspace as workspace_api
from fabric_cli.core import fab_constant, fab_logger
from fabric_cli.core.fab_exceptions import FabricCLIError
from fabric_cli.core.fab_hiearchy import FabricElement, VirtualWorkspaceItem, Workspace
from fabric_cli.core.fab_types import VirtualWorkspaceItemType


def exec_command(
    args: Namespace, from_context: FabricElement, to_context: FabricElement
) -> None:
    force_assign = bool(args.force)
    if isinstance(from_context, VirtualWorkspaceItem):
        _assign_virtual_ws_item(from_context, to_context, args, force_assign)


# Virtual Workspace Items
def _assign_virtual_ws_item(
    virtual_ws_item: VirtualWorkspaceItem,
    ws: FabricElement,
    args: Namespace,
    force_assign: bool,
) -> None:
    if virtual_ws_item.get_item_type() == VirtualWorkspaceItemType.CAPACITY:
        _assign_capacity(virtual_ws_item, ws, args, force_assign)
    if virtual_ws_item.get_item_type() == VirtualWorkspaceItemType.DOMAIN:
        _assign_domain(virtual_ws_item, ws, args, force_assign)


# Virtual Workspace Items - Capacity
def _assign_capacity(
    virtual_ws_item: VirtualWorkspaceItem,
    ws: FabricElement,
    args: Namespace,
    force_assign: bool,
) -> None:
    if isinstance(ws, Workspace):
        payload = json.dumps(
            {
                "capacityId": f"{virtual_ws_item.get_id()}",
            }
        )

        args.ws_id = ws.get_id()
        args.name = virtual_ws_item.get_name()
        workspace_api.assign_to_capacity(args, payload, force_assign)
    else:
        raise FabricCLIError(
            "Capacity can only be assigned to a workspace",
            fab_constant.ERROR_NOT_SUPPORTED,
        )


# Virtual Workspace Items - Domain
def _assign_domain(
    virtual_ws_item: VirtualWorkspaceItem,
    ws: FabricElement,
    args: Namespace,
    force_assign: bool,
) -> None:
    fab_logger.log_warning(fab_constant.WARNING_FABRIC_ADMIN_ROLE)
    if isinstance(ws, Workspace):
        payload = json.dumps(
            {
                "workspacesIds": [f"{ws.get_id()}"],
            }
        )

        args.id = virtual_ws_item.get_id()
        args.name = virtual_ws_item.get_name()
        domain_api.assign_to_workspaces(args, payload, force_assign)
    else:
        raise FabricCLIError(
            "Domain can only be assigned to a workspace",
            fab_constant.ERROR_NOT_SUPPORTED,
        )
