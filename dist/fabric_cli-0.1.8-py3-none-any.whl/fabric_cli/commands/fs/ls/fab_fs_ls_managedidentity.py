import json

from fabric_cli.client import fab_api_workspace as workspace_api
from fabric_cli.core.fab_hiearchy import VirtualItemContainer
from fabric_cli.utils import fab_mem_store as utils_mem_store
from fabric_cli.utils import fab_ui as utils_ui


def exec(vic: VirtualItemContainer, args, show_details):
    managed_identities = utils_mem_store.get_managed_identities(vic)

    if managed_identities:
        sorted_managed_identities = sorted(
            [{"name": mi.get_name(), "id": mi.get_id()}
             for mi in managed_identities],
            key=lambda item: item["name"],
        )
        base_cols = ["name"]
        if show_details:
            mi_detail_cols = ["servicePrincipalId", "applicationId"]

            args.ws_id = vic.get_workspace_id()
            response = workspace_api.get_workspace(args)
            if response.status_code in {200, 201}:
                _managed_identities: list = [
                    json.loads(response.text)["workspaceIdentity"]
                ]
                for managed_identity in sorted_managed_identities:
                    mi_details: dict[str, str] = next(
                        (
                            c
                            for c in _managed_identities
                            if c["servicePrincipalId"] == managed_identity["id"]
                        ),
                        {},
                    )
                    for col in mi_detail_cols:
                        managed_identity[col] = mi_details.get(col, "Unknown")

        columns = base_cols + mi_detail_cols if show_details else base_cols
        utils_ui.print_entries_unix_style(
            sorted_managed_identities, columns, header=show_details
        )
