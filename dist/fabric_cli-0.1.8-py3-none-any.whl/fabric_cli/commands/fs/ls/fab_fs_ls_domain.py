import json

from fabric_cli.client import fab_api_domain as domain_api
from fabric_cli.core import fab_constant, fab_logger
from fabric_cli.core.fab_hiearchy import VirtualWorkspace
from fabric_cli.utils import fab_cmd_ls_utils as utils_ls
from fabric_cli.utils import fab_mem_store as utils_mem_store
from fabric_cli.utils import fab_ui as utils_ui


def exec(vws: VirtualWorkspace, args, show_details):
    fab_logger.log_warning(fab_constant.WARNING_FABRIC_ADMIN_ROLE)
    domains = utils_mem_store.get_domains(vws.get_tenant())
    sorted_domains = sorted(
        [{"name": d.get_name(), "id": d.get_id()} for d in domains],
        key=lambda item: item["name"],
    )

    base_cols = ["name"]

    if show_details:
        domains_detail_cols = [
            "id",
            "contributorsScope",
            "description",
            "parentDomainId",
        ]
        fab_response = domain_api.list_domains(args)
        if fab_response.status_code in {200, 201}:
            _domains: list = json.loads(fab_response.text)["domains"]
            for domain in sorted_domains:
                domain_details: dict[str, str] = next(
                    (d for d in _domains if d["id"] == domain["id"]), {}
                )
                for col in domains_detail_cols:
                    domain[col] = domain_details.get(col, "Unknown")

                # enrich with parentDomainName
                domain["parentDomainName"] = utils_ls.get_domain_name_by_id(
                    domains, domain.get("parentDomainId")
                )
        domains_detail_cols.insert(3, "parentDomainName")

    columns = base_cols + domains_detail_cols if show_details else base_cols
    utils_ui.print_entries_unix_style(
        sorted_domains, columns, header=show_details)
