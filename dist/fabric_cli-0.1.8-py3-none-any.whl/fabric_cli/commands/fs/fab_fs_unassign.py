import json
from argparse import Namespace

from fabric_cli.client import fab_api_domain as domain_api
from fabric_cli.client import fab_api_workspace as workspace_api
from fabric_cli.core import fab_constant, fab_logger
from fabric_cli.core.fab_exceptions import FabricCLIError
from fabric_cli.core.fab_hiearchy import FabricElement, VirtualWorkspaceItem, Workspace
from fabric_cli.core.fab_types import VirtualWorkspaceItemType


def exec_command(
    args: Namespace, from_context: FabricElement, to_context: FabricElement
) -> None:
    force_unassign = bool(args.force)
    if isinstance(from_context, VirtualWorkspaceItem):
        _unassign_virtual_ws_item(from_context, to_context, args, force_unassign)


# Virtual Workspace Items
def _unassign_virtual_ws_item(
    virtual_ws_item: VirtualWorkspaceItem,
    ws: FabricElement,
    args: Namespace,
    force_unassign: bool,
) -> None:
    if virtual_ws_item.get_item_type() == VirtualWorkspaceItemType.CAPACITY:
        _unassign_capacity(virtual_ws_item, ws, args, force_unassign)
    if virtual_ws_item.get_item_type() == VirtualWorkspaceItemType.DOMAIN:
        _unassign_domain(virtual_ws_item, ws, args, force_unassign)


# Virtual Workspace Items - Capacity
def _unassign_capacity(
    virtual_ws_item: VirtualWorkspaceItem,
    ws: FabricElement,
    args: Namespace,
    force_unassign: bool,
) -> None:
    if isinstance(ws, Workspace):

        get_args = Namespace()
        get_args.ws_id = ws.get_id()
        response = workspace_api.get_workspace(get_args)
        workspace = json.loads(response.text)
        capacity_id = workspace.get("capacityId", None)
        if capacity_id != virtual_ws_item.get_id():
            raise FabricCLIError(
                f"Cannot unassign capacity: Workspace not linked to it",
                fab_constant.ERROR_INVALID_INPUT,
            )

        args.ws_id = ws.get_id()
        args.name = virtual_ws_item.get_name()

        workspace_api.unassign_from_capacity(args, force_unassign)

        # if workspace_api.unassign_from_capacity(args, force_unassign):
        #     utils_ui.print_done(
        #         f"Capacity {virtual_ws_item.get_name()} is unassigned from {ws.get_name()}"
        #     )
    else:
        raise FabricCLIError(
            "Capacity can only be unassigned from a workspace",
            fab_constant.ERROR_NOT_SUPPORTED,
        )


# Virtual Workspace Items - Domain
def _unassign_domain(
    virtual_ws_item: VirtualWorkspaceItem,
    ws: FabricElement,
    args: Namespace,
    force_unassign: bool,
) -> None:
    fab_logger.log_warning(fab_constant.WARNING_FABRIC_ADMIN_ROLE)
    if isinstance(ws, Workspace):
        args.id = virtual_ws_item.get_id()
        args.name = virtual_ws_item.get_name()
        ws_id = ws.get_id()

        # Validate that the workspace is assigned to the Domain
        response = domain_api.list_domain_workspaces(args)
        _assigned_workspaces: list = json.loads(response.text)["value"]
        if not ws_id in [ws["id"] for ws in _assigned_workspaces]:
            raise FabricCLIError(
                f"Cannot unassign domain: Workspace not linked to it",
                fab_constant.ERROR_INVALID_INPUT,
            )

        payload = json.dumps(
            {
                "workspacesIds": [f"{ws_id}"],
            }
        )

        domain_api.unassign_from_workspaces(args, payload, force_unassign)

    else:
        raise FabricCLIError(
            "Domain can only be unassigned from a workspace",
            fab_constant.ERROR_NOT_SUPPORTED,
        )
