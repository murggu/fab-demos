import json
from argparse import Namespace

from fabric_cli.client import fab_api_client as fabric_api
from fabric_cli.utils import fab_jmespath as utils_jmespath
from fabric_cli.utils import fab_ui as utils_ui
from fabric_cli.utils import fab_util as utils


def exec_command(args: Namespace) -> None:
    args.raw_response = True
    args.uri = args.endpoint
    if args.input is not None:
        response = fabric_api.do_request(args, json=args.input)
    else:
        response = fabric_api.do_request(args)

    # Build the JSON payload
    payload = {
        "status_code": response.status_code,
        "headers": dict(response.headers) if args.show_headers else None,
        "text": json.loads(response.text) if response.text.strip() else "(Empty)"
    }

    # Filter based on JMESPath
    query = utils.process_nargs(args.query)
    if query:
        try:
            payload_jmespath = utils_jmespath.search(payload, query)
            if payload_jmespath:
                payload = json.loads(payload_jmespath)
        except (json.JSONDecodeError, TypeError):
            utils_ui.print_api_response(payload_jmespath)
            return

    # Remove None values from the payload
    payload = {k: v for k, v in payload.items() if v is not None}
    utils_ui.print_api_response(payload)
