import json
from argparse import Namespace
from typing import Optional

from fabric_cli.client import fab_api_onelake as onelake_api
from fabric_cli.core.fab_exceptions import FabricCLIError
from fabric_cli.core.fab_hiearchy import OneLakeItem
from fabric_cli.utils import fab_handle_context as handle_context
from fabric_cli.utils import fab_ui as utils_ui
from fabric_cli.utils import fab_util as utils


def exec_command(args: Namespace) -> None:
    schema = _extract_schema_from_commit_logs(args)
    if schema:
        utils_ui.print_done("Schema extracted successfully")
        _pretty_print_schema(schema)
    else:
        raise FabricCLIError("Failed to extract schema")


def _pretty_print_schema(schema: str) -> None:
    _schema = json.loads(schema)["fields"]
    utils_ui.print_entries_unix_style(_schema, ["name", "type"], header=True)


def _get_commit_logs(args: Namespace) -> Optional[list[str]]:
    _delta_log_path = args.path
    _delta_log_path[-1] = _delta_log_path[-1] + "/_delta_log"

    onelake: OneLakeItem = handle_context.get_command_context(
        _delta_log_path, raise_error=True
    )
    workspace_id = onelake.get_workspace_id()
    item_id = onelake.get_item_id()
    local_path = onelake.get_local_path()

    local_path = utils.remove_dot_suffix(local_path)
    args.directory = f"{workspace_id}/?recursive=false&resource=filesystem&directory={item_id}/{local_path}&getShortcutMetadata=true"
    response = onelake_api.list_tables_files_recursive(args)

    if response.status_code in {200, 201}:
        file_names = [f["name"] for f in response.json().get("paths", [])]
        json_files = [
            f"{workspace_id}/{item_id}/{f.split('/', 1)[1]}"
            for f in file_names
            if f.endswith(".json") and f != "_temporary"
        ]
        json_files.sort(reverse=True)
        return json_files
    return None


def _extract_schema_from_commit_logs(args: Namespace) -> Optional[str]:
    commit_logs = _get_commit_logs(args)

    if not commit_logs:
        return None

    for log in commit_logs:
        args.from_path = log
        args.wait = True
        response = onelake_api.read(args)

        if response.status_code in {200, 201}:
            json_string = response.text
            json_objects = json_string.strip().split("\n")

            for obj in json_objects:
                commit_data = json.loads(obj)
                if "metaData" in commit_data:
                    metadata = commit_data["metaData"]
                    schema = metadata["schemaString"]
                    return schema

    return None
