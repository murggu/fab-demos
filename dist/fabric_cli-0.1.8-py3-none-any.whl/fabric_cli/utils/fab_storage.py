import json
import os
from argparse import Namespace
from datetime import datetime

from fabric_cli.client import fab_api_onelake as onelake_api
from fabric_cli.core import fab_constant
from fabric_cli.core.fab_exceptions import FabricCLIError
from fabric_cli.core.fab_hiearchy import Item, OneLakeItem
from fabric_cli.core.fab_types import ItemType
from fabric_cli.utils import fab_handle_context as handle_context
from fabric_cli.utils import fab_ui as utils_ui


def write_to_storage(export_path, data, export=False, content_type="application/json"):
    if export_path["type"] == "lakehouse":
        _write_to_lakehouse(export_path["path"], data, export)
    elif export_path["type"] == "local":
        _write_to_local(export_path["path"], data, export)
    elif export_path["type"] == "sparkJobDefinition":
        _write_to_sjd(export_path["path"], data, export, content_type)


def _write_to_local(file_path, data, export):

    file_path = os.path.normpath(file_path)
    file_dir = os.path.dirname(file_path)

    if not os.path.exists(file_dir):
        # parent_dir = os.path.dirname(file_dir)
        # if not os.path.exists(parent_dir):
        #     raise FabricCLIError(
        #         f"Cannot access '{parent_dir}'. No such file or directory"
        #     )
        os.makedirs(file_dir, exist_ok=False)

    processed_data, is_json = _validate_json(data)
    try:
        if is_json:
            if not export:
                file_path += ".json"
            with open(file_path, "w") as f:
                json.dump(processed_data, f, indent=4)
            if not export:
                utils_ui.print_done("Export completed")
        else:
            with open(file_path, "w") as f:
                f.write(
                    processed_data
                    if isinstance(processed_data, str)
                    else str(processed_data)
                )
            if not export:
                utils_ui.print_done("Export completed")
    except Exception as e:
        raise IOError(f"Failed to write to local file: {e}")


def _write_to_lakehouse(file_path, data, export):

    processed_data, is_json = _validate_json(data)
    if is_json:
        data = json.dumps(processed_data)
        if not export:
            file_path += ".json"

    file_path = file_path.replace(".Workspace", "", 1).replace(".workspace", "", 1)
    args = Namespace()
    args.to_path = file_path

    try:
        response = onelake_api.touch_file(args)
        if response.status_code == 201:
            if len(data) > 0:
                onelake_api.append_file(args, data, 0)
            onelake_api.flush_file(args, len(data))
            if not export:
                utils_ui.print_done("Export completed")
    except Exception as e:
        raise e


def _write_to_sjd(file_path, data, export, content_type="application/json"):

    args = Namespace()
    args.to_path = file_path

    try:
        response = onelake_api.touch_file(args)
        if response.status_code == 201:
            onelake_api.append_file(args, data, 0, content_type)
            onelake_api.flush_file(args, len(data))
    except Exception as e:
        raise FabricCLIError(f"Cannot access '{file_path}'. No such file or directory")


# Utils
def _validate_json(data):
    try:
        if isinstance(data, str):
            return json.loads(data), True
        elif isinstance(data, (dict, list)):
            return data, True
        else:
            return data, False
    except json.JSONDecodeError:
        return data, False


def get_export_path(output_path):
    onelake_export_path = None

    try:
        # Try to obtain a valid Fabric context
        onelake_export_path = handle_context.get_command_context(output_path)
    except Exception as e:
        # Try to obtain a local path
        if output_path:
            if os.path.exists(output_path):
                return {"type": "local", "path": output_path}
            else:
                raise FabricCLIError(
                    "No such file or directory", fab_constant.ERROR_INVALID_PATH
                )

    # Validate Fabric path if exists
    if onelake_export_path and isinstance(onelake_export_path, OneLakeItem):
        parent_item: Item = onelake_export_path.get_parent()
        item_type = parent_item.get_item_type()

        if (
            item_type != ItemType.LAKEHOUSE
            or not onelake_export_path.get_local_path().startswith("Files")
        ):
            raise FabricCLIError(
                "Only supported for Lakehouse/Files",
                fab_constant.ERROR_NOT_SUPPORTED,
            )
        return {
            "type": "lakehouse",
            "path": onelake_export_path.get_path().strip("/"),
        }
    else:
        raise FabricCLIError(
            "Only supported for Lakehouse/Files",
            fab_constant.ERROR_NOT_SUPPORTED,
        )


def get_import_path(input_path):
    onelake_import_path = None
    export_path = None

    try:
        # Try to obtain a valid Fabric context
        onelake_import_path = handle_context.get_command_context(input_path)
    except Exception as e:
        # Try to obtain a local path
        if os.path.exists(input_path):
            export_path = {"type": "local", "path": input_path}
        else:
            raise FabricCLIError(
                "No such file or directory", fab_constant.ERROR_INVALID_PATH
            )

    # Validate Fabric path if exists
    if onelake_import_path and isinstance(onelake_import_path, OneLakeItem):
        parent_item: Item = onelake_import_path.get_parent()
        item_type = parent_item.get_item_type()

        if (
            item_type != ItemType.LAKEHOUSE
            or not onelake_import_path.get_local_path().startswith("Files/")
        ):
            raise FabricCLIError(
                "Only supported for Lakehouse/Files",
                fab_constant.ERROR_NOT_SUPPORTED,
            )
        export_path = {
            "type": "lakehouse",
            "path": onelake_import_path.get_path().strip("/"),
        }

    if export_path is None:
        raise FabricCLIError("Invalid_path: No such file or directory")

    return export_path


def do_output(data, file_name, args):
    export_path = get_export_path(args.output)

    export_path["path"] = _create_get_export_file_name(
        f"{export_path['path']}/{file_name}"
    )

    file_path = export_path["path"]
    _, is_json = _validate_json(data)
    if is_json:
        file_path = file_path + ".json"

    utils_ui.print_grey(f"Exporting result to '{file_path}'...")
    write_to_storage(export_path, data)


def _create_get_export_file_name(path):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    file_name = f"get_{timestamp}"
    return os.path.join(path, file_name)
