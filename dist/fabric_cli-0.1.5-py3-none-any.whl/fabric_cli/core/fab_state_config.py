import json
import os
from os.path import exists, expanduser

from cryptography.fernet import Fernet


def config_location():
    _location = expanduser("~/.config/fab/")
    if not exists(_location):
        os.makedirs(_location)
    return _location


# config_file = 'config.json'
config_file = os.path.join(config_location(), "config.json")

# auth_file = 'auth.json'
auth_file = os.path.join(config_location(), "auth.json")

# Store the key in memory, only valid for the current session
_key = Fernet.generate_key()


def read_config(file_path) -> dict:
    try:
        with open(file_path, "r") as file:
            return json.load(file)
    except FileNotFoundError:
        return {}
    except json.JSONDecodeError:
        return {}


def write_config(data):
    with open(config_file, "w") as file:
        json.dump(data, file, indent=4)


def set_config(key, value):
    config = read_config(config_file)
    config[key] = value
    write_config(config)


def set_secure_config(key, value):
    f = Fernet(_key)
    value = f.encrypt(value.encode()).decode()
    set_config(key, value)


def get_config(key):
    config = read_config(config_file)
    auth_config = read_config(auth_file)
    combined_config = {**config, **auth_config}
    return combined_config.get(key)


def get_secure_config(key):
    f = Fernet(_key)
    value = get_config(key)
    if value:
        return f.decrypt(value.encode()).decode()
    return None


def list_configs():
    config = read_config(config_file)
    # auth_config = read_config(auth_file)
    # return {**config, **auth_config}
    return {**config}
