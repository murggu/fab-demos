from fabric_cli.config import fab_config as config
from fabric_cli.core import fab_constant
from fabric_cli.utils import fab_error_parser as utils_error_parser
from fabric_cli.utils import fab_ui as utils_ui

commands = {
    "Commands": {
        "clear-cache": "Clear the CLI cache.",
        "get": "Print the value of a given configuration key.",
        utils_ui.get_os_specific_command(
            "ls"
        ): "List all configuration keys and their values.",
        "set": "Set a configuration key to a specified value.",
    }
}


def register_parser(subparsers):
    parser = subparsers.add_parser(
        "config", help=fab_constant.COMMAND_CONFIG_DESCRIPTION
    )
    parser.set_defaults(func=show_help)
    config_subparsers = parser.add_subparsers(dest="config_subcommand")

    # Subcommand for 'set'
    set_examples = [
        "# switch to command line mode",
        "$ config set fab_mode command_line\n",
        "# set default capacity",
        "$ config set fab_default_capacity Trial-0000",
    ]

    parser_set = config_subparsers.add_parser(
        "set",
        help="Set a configuration value",
        fab_examples=set_examples,
    )
    parser_set.add_argument("key", metavar="<key>", help="Configuration key")
    parser_set.add_argument("value", metavar="<value>", help="Configuration value")

    parser_set.usage = f"{utils_error_parser.get_usage_prog(parser_set)}"
    parser_set.set_defaults(func=config.set_config)

    # Subcommand for 'get'
    get_examples = [
        "# get current CLI mode",
        "$ config get fab_mode\n",
        "# get default capacity",
        "$ config get fab_default_capacity",
    ]

    parser_get = config_subparsers.add_parser(
        "get",
        help="Get a configuration value",
        fab_examples=get_examples,
    )
    parser_get.add_argument("key", metavar="<key>", help="Configuration key")

    parser_get.usage = f"{utils_error_parser.get_usage_prog(parser_get)}"
    parser_get.set_defaults(func=config.get_config)

    # Subcommand for 'ls'
    ls_examples = ["# print configuration values", "$ config ls"]

    parser_ls = config_subparsers.add_parser(
        "ls",
        help="List all configuration values",
        aliases=["dir"],
        fab_examples=ls_examples,
    )

    parser_ls.usage = f"{utils_error_parser.get_usage_prog(parser_ls)}"
    parser_ls.set_defaults(func=config.list_configs)

    # Subcommand for 'clear-cache'
    clearcache_examples = ["# clear CLI cache", "$ config clear-cache"]

    parser_clear_cache = config_subparsers.add_parser(
        "clear-cache",
        help="Clear cache",
        fab_examples=clearcache_examples,
    )

    parser_clear_cache.usage = (
        f"{utils_error_parser.get_usage_prog(parser_clear_cache)}"
    )
    parser_clear_cache.set_defaults(func=config.clear_cache)


def show_help(args):
    utils_ui.display_help(
        commands, custom_header=fab_constant.COMMAND_CONFIG_DESCRIPTION
    )
