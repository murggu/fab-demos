from fabric_cli.config import fab_config_clear_cache as config_clear_cache
from fabric_cli.config import fab_config_get as config_get
from fabric_cli.config import fab_config_ls as config_ls
from fabric_cli.config import fab_config_set as config_set
from fabric_cli.utils.fab_error_parser import handle_custom_exceptions
from fabric_cli.utils.fab_util import set_command_context


@handle_custom_exceptions()
@set_command_context()
def set_config(args):
    config_set.exec_command(args)


@handle_custom_exceptions()
@set_command_context()
def get_config(args):
    config_get.exec_command(args)


@handle_custom_exceptions()
@set_command_context()
def list_configs(args):
    config_ls.exec_command(args)


@handle_custom_exceptions()
@set_command_context()
def clear_cache(args):
    config_clear_cache.exec_command(args)
