from fabric_cli.core import fab_constant, fab_logger


def register_parser(subparsers):
    parser = subparsers.add_parser(
        "extension", help=fab_constant.COMMAND_EXTENSIONS_DESCRIPTION
    )
    parser.set_defaults(func=show_help)


def show_help(args):
    fab_logger.log_warning(fab_constant.INFO_FEATURE_NOT_SUPPORTED, args.command_path)
