import base64
import os

from fabric_cli.core.fab_hiearchy import Item


def get_payload_for_item_type(path, item: Item, input_format=None):
    base64_definition = _build_payload(path)
    return item.get_payload(base64_definition, input_format)


def _build_payload(input_path):
    """Recursively traverses the directory and builds the payload structure."""

    directory = input_path

    parts = []
    for root, dirs, files in os.walk(directory):
        for file in files:
            # Get full path and relative path
            full_path = os.path.join(root, file)
            relative_path = os.path.relpath(full_path, directory)

            # Encode the file content to base64
            encoded_content = _encode_file_to_base64(full_path)

            # Add file data to parts
            parts.append(
                {
                    "path": relative_path.replace(
                        "\\", "/"
                    ),  # Ensure cross-platform path formatting
                    "payload": encoded_content,
                    "payloadType": "InlineBase64",
                }
            )

    # Create the final JSON structure
    payload_structure = {"parts": parts}
    return payload_structure


def _encode_file_to_base64(file_path):
    with open(file_path, "rb") as file:
        return base64.b64encode(file.read()).decode("utf-8")
