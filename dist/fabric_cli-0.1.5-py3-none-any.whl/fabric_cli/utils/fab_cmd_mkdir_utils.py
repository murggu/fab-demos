import base64
import json
import os
from argparse import Namespace

from fabric_cli.client import fab_api_subscriptions as subscriptions_api
from fabric_cli.client import fab_api_vnet as vnet_api
from fabric_cli.client import fab_api_managedPrivateEndpoint as mpe_api
from fabric_cli.core import fab_constant, fab_logger
from fabric_cli.core.fab_hiearchy import Item
from fabric_cli.core.fab_types import ItemType
from fabric_cli.fs import fab_fs_mkdir as fs_mkdir
from fabric_cli.utils import fab_ui as utils_ui
from fabric_cli.utils import fab_util as utils
from fabric_cli.utils.fab_custom_exception import CustomError


def add_type_specific_payload(item: Item, args, payload):

    # Lowercase params
    params = args.params

    payload_dict = payload
    item_type = item.get_item_type()
    current_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.abspath(os.path.join(current_dir, ".."))

    match item_type:

        case ItemType.LAKEHOUSE:
            if params.get("enableschemas", "False").lower() == "true":
                payload_dict["creationPayload"] = {"enableSchemas": True}
                # is this needed at all?
                # args.params.pop("enableSchemas")

        case ItemType.WAREHOUSE:
            payload_dict["creationPayload"] = {
                "defaultCollation": "Latin1_General_100_BIN2_UTF8"
            }
            if params.get("enablecaseinsensitive", "False").lower() == "true":
                payload_dict["creationPayload"] = {
                    "defaultCollation": "Latin1_General_100_CI_AS_KS_WS_SC_UTF8"
                }
            # is this needed at all?
            # if params.get("enablecaseinsensitive"):
            # args.params.pop("enableCaseSensitive")

        case ItemType.KQL_DATABASE:
            _eventhouse_id = params.get("eventhouseid")
            _cluster_uri = params.get("clusteruri")
            _database_name = params.get("databasename")
            _type = params.get("dbtype", "readwrite")

            # ReadWrite DB
            if _eventhouse_id and _type.lower() == "readwrite":
                payload_dict["creationPayload"] = {
                    "databaseType": "ReadWrite",
                    "parentEventhouseItemId": _eventhouse_id,
                }
            # Shortcut DBS
            elif (
                _eventhouse_id
                and _type.lower() == "shortcut"
                and _cluster_uri
                and _database_name
            ):
                payload_dict["creationPayload"] = {
                    "databaseType": "Shortcut",
                    "parentEventhouseItemId": _eventhouse_id,
                    "sourceClusterUri": _cluster_uri,
                    "sourceDatabaseName": _database_name,
                }
            # Default
            else:
                fab_logger.log_warning(
                    "EventHouse not provided in params. Creating one first"
                )

                # Create a new Event House first
                _eventhouse = Item(
                    f"{item.get_short_name()}_auto",
                    None,
                    item.get_parent(),
                    "EventHouse",
                )
                _eventhouse_id = fs_mkdir._mkdir_item(_eventhouse, args)

                payload_dict["creationPayload"] = {
                    "databaseType": "ReadWrite",
                    "parentEventhouseItemId": _eventhouse_id,
                }

        case ItemType.MIRRORED_DATABASE:
            _type = "genericmirror"
            payload_folder = "MirroredDatabase.GenericMirror"

            if params.get("mirrortype"):
                _type = params.get("mirrortype")
                match _type.lower():
                    case "azuresql":
                        fab_logger.log_warning(
                            "Requires system-assigned managed identity on"
                        )
                        payload_folder = "MirroredDatabase.AzureSQLDatabase"
                    case "azuresqlmi":
                        payload_folder = "MirroredDatabase.AzureSqlMI"
                    case "snowflake":
                        payload_folder = "MirroredDatabase.Snowflake"
                    case "cosmosdb":
                        payload_folder = "MirroredDatabase.CosmosDb"
                    case "genericmirror":
                        payload_folder = "MirroredDatabase.GenericMirror"

            payload_path = os.path.join(
                project_root,
                "fs",
                "payloads",
                payload_folder,
            )

            payload_dict["definition"] = _create_payload(payload_path, params, _type)

        case ItemType.REPORT:
            payload_folder = "Blank.Report"

            if params.get("semanticmodelid"):
                _semantic_model_id = params.get("semanticmodelid")
            else:
                fab_logger.log_warning(
                    "Semantic Model not provided in params. Creating one first"
                )

                # Create a new Semantic Model first
                _semantic_model = Item(
                    f"{item.get_short_name()}_auto",
                    None,
                    item.get_parent(),
                    "SemanticModel",
                )
                _semantic_model_id = fs_mkdir._mkdir_item(_semantic_model, args)

            payload_path = os.path.join(project_root, "fs", "payloads", payload_folder)
            payload_dict["definition"] = _create_payload(
                payload_path, params, semantic_model_id=_semantic_model_id
            )

        case ItemType.SEMANTIC_MODEL:
            payload_folder = "Blank.SemanticModel"
            payload_path = os.path.join(project_root, "fs", "payloads", payload_folder)
            payload_dict["definition"] = _create_payload(payload_path, params)

        case ItemType.NOTEBOOK:
            # markdown metadata, same as web
            payload_dict["definition"] = {
                "parts": [
                    {
                        "path": "notebook-content.py",
                        "payload": "IyBGYWJyaWMgbm90ZWJvb2sgc291cmNlCgojIE1FVEFEQVRBICoqKioqKioqKioqKioqKioqKioqCgojIE1FVEEgewojIE1FVEEgICAia2VybmVsX2luZm8iOiB7CiMgTUVUQSAgICAgIm5hbWUiOiAic3luYXBzZV9weXNwYXJrIgojIE1FVEEgICB9LAojIE1FVEEgICAiZGVwZW5kZW5jaWVzIjoge30KIyBNRVRBIH0KCiMgQ0VMTCAqKioqKioqKioqKioqKioqKioqKgoKIyBXZWxjb21lIHRvIHlvdXIgbmV3IG5vdGVib29rCiMgVHlwZSBoZXJlIGluIHRoZSBjZWxsIGVkaXRvciB0byBhZGQgY29kZSEKCgojIE1FVEFEQVRBICoqKioqKioqKioqKioqKioqKioqCgojIE1FVEEgewojIE1FVEEgICAibGFuZ3VhZ2UiOiAicHl0aG9uIiwKIyBNRVRBICAgImxhbmd1YWdlX2dyb3VwIjogInN5bmFwc2VfcHlzcGFyayIKIyBNRVRBIH0K",
                        "payloadType": "InlineBase64",
                    }
                ]
            }

    # is this needed at all?
    # if payload_dict.get("creationPayload"):
    #    payload_dict["creationPayload"].update(args.params)

    return payload_dict


def _create_payload(directory, params, type=None, semantic_model_id=None, encode=True):
    parts = []
    for root, dirs, files in os.walk(directory):
        for file in files:
            # Get full path and relative path
            full_path = os.path.join(root, file)
            relative_path = os.path.relpath(full_path, directory)

            if semantic_model_id and "definition.pbir" in full_path:

                # Change byPath to byConnection
                with open(full_path, "rb") as file:
                    data = json.load(file)

                data["datasetReference"]["byPath"] = None

                data["datasetReference"]["byConnection"] = {
                    "connectionString": "Data Source=powerbi://api.powerbi.com/v1.0/myorg/mkdir;Initial Catalog=r3;Integrated Security=ClaimsToken",
                    "pbiServiceModelId": None,
                    "pbiModelVirtualServerName": "sobe_wowvirtualserver",
                    "pbiModelDatabaseName": semantic_model_id,
                    "name": "EntityDataSource",
                    "connectionType": "pbiServiceXmlaStyleLive",
                }

                # Encode the file content to base64
                json_str = json.dumps(data)
                encoded_content = base64.b64encode(json_str.encode("utf-8")).decode(
                    "utf-8"
                )

            elif type and type.lower() != "genericmirror":

                # Change payload based on params
                with open(full_path, "rb") as file:
                    data = json.load(file)

                data["properties"]["source"]["typeProperties"]["connection"] = (
                    params.get("connectionid")
                )
                data["properties"]["target"]["typeProperties"]["defaultSchema"] = (
                    params.get("defaultschema")
                )

                # Encode the file content to base64
                json_str = json.dumps(data)
                encoded_content = base64.b64encode(json_str.encode("utf-8")).decode(
                    "utf-8"
                )

            else:

                # Encode the file content to base64
                with open(full_path, "rb") as file:
                    content = file.read()
                    encoded_content = (
                        base64.b64encode(content).decode("utf-8") if encode else content
                    )

            # Add file data to parts
            parts.append(
                {
                    "path": relative_path.replace(
                        "\\", "/"
                    ),  # Ensure cross-platform path formatting
                    "payload": encoded_content,
                    "payloadType": "InlineBase64",
                }
            )

    # Create the final JSON structure
    payload_structure = {"parts": parts}
    return payload_structure


def get_params_per_item_type(item: Item):
    required_params = None
    optional_params = None

    match item.get_item_type():
        case ItemType.LAKEHOUSE:
            optional_params = ["enableSchemas"]
        case ItemType.WAREHOUSE:
            optional_params = ["enableCaseInsensitive"]
        case ItemType.KQL_DATABASE:
            optional_params = ["dbType", "eventhouseId", "clusterUri", "databaseName"]
        case ItemType.MIRRORED_DATABASE:
            optional_params = ["mirrorType", "connectionId", "defaultSchema"]
        case ItemType.REPORT:
            optional_params = ["semanticModelId"]

    return required_params, optional_params


def show_params_desc(params, type, required_params=None, optional_params=None):

    if not params:
        required_params_filtered = [p for p in (required_params or []) if p is not None]
        optional_params_filtered = [p for p in (optional_params or []) if p is not None]

        # Construct the parts of the message conditionally
        required_param_list = "\n  ".join(sorted(required_params_filtered))
        optional_param_list = "\n  ".join(sorted(optional_params_filtered))

        if required_params is None and optional_params is None:
            message_parts = [f"No parameters for '.{type}'"]
        else:
            message_parts = [
                f"Params for '.{type}'. Use key=value separated by commas."
            ]

            if required_param_list:
                message_parts.append(f"\n\nRequired params:\n  {required_param_list}")
            if optional_param_list:
                message_parts.append(f"\n\nOptional params:\n  {optional_param_list}")

        utils_ui.print("".join(message_parts) + "\n")

        return True
    elif params.get("run"):
        return False


def _validate_credential_params(cred_type, provided_cred_params):
    # Documented credential types: https://learn.microsoft.com/en-us/rest/api/fabric/core/connections/create-connection?tabs=HTTP#credentialtype
    ignored_params = []
    params = {}
    match cred_type:
        case "Anonymous" | "WindowsWithoutImpersonation" | "WorkspaceIdentity":
            param_keys = []
        case "Basic" | "Windows":
            param_keys = ["username", "password"]
        case "Key":
            param_keys = ["key"]
        case "OAuth2":
            raise CustomError(
                "OAuth2 credential type is not supported.",
                fab_constant.ERROR_NOT_SUPPORTED,
            )
        case "ServicePrincipal":
            param_keys = [
                "servicePrincipalClientId",
                "servicePrincipalSecret",
                "tenantId",
            ]
        case "SharedAccessSignature":
            param_keys = ["token"]
        case _:
            utils_ui.print_warning(
                f"Unsupported credential type {cred_type}. Skipping validation"
            )

    missing_params = [key for key in param_keys if key not in provided_cred_params]
    if len(missing_params) > 0:
        raise CustomError(
            f"Missing parameters for credential type {cred_type}: {missing_params}",
            fab_constant.ERROR_INVALID_INPUT,
        )

    ignored_params = [key for key in provided_cred_params if key not in param_keys]
    if len(ignored_params) > 0:
        utils_ui.print_warning(
            f"Ignoring unsupported parameters for credential type {cred_type}: {ignored_params}"
        )

    for key in param_keys:
        params[key] = provided_cred_params[key]

    return params


def get_connection_config_from_params(payload, con_type, con_type_def, params):
    connection_request = payload

    # Get and set Privacy Level
    supported_privacy_levels = ["None", "Organizational", "Private", "Public"]
    privacy_level = params.get("privacylevel", "None")
    if privacy_level not in supported_privacy_levels:
        raise CustomError(
            f"Invalid privacy level. Supported privacy levels are {supported_privacy_levels}",
            fab_constant.ERROR_INVALID_INPUT,
        )
    connection_request["privacyLevel"] = privacy_level

    # Check and build the connection details
    # "connectionDetails": {
    #   "type": "SQL",
    #   "creationMethod": "SQL",
    #   "parameters": [
    #     {
    #       "dataType": "Text",
    #       "name": "server",
    #       "value": "contoso.database.windows.net"
    #     },
    #     {
    #       "dataType": "Text",
    #       "name": "database",
    #       "value": "sales"
    #     }
    #   ]
    # }
    if not params.get("connectiondetails"):
        raise CustomError(
            "Connection details are required", fab_constant.ERROR_INVALID_INPUT
        )
    provided_params = params.get("connectiondetails").get("parameters")
    if not params.get("connectiondetails").get("creationmethod"):
        # We default to pick the first creation method that matches the provided parameters
        creation_method = next(
            (
                item
                for item in con_type_def["creationMethods"]
                if all(
                    k["name"]
                    in params.get("connectiondetails").get("parameters").keys()
                    for k in item["parameters"]
                )
            ),
            None,
        )
    else:
        provided_method = params.get("connectiondetails").get("creationmethod")
        creation_method = next(
            (
                item
                for item in con_type_def["creationMethods"]
                if item["name"].lower() == provided_method.lower()
            ),
            None,
        )

    if creation_method is None:
        supported_creation_methods = [
            m["name"] for m in con_type_def["creationMethods"]
        ]
        raise CustomError(
            f"Invalid creation method. Supported creation methods for {con_type} are {supported_creation_methods}",
            fab_constant.ERROR_INVALID_INPUT,
        )

    parsed_params = []
    for param in creation_method["parameters"]:
        p_name = param["name"]
        if p_name not in provided_params and param["required"]:
            c_method = creation_method["name"]
            raise CustomError(
                f"Missing parameter {p_name} for creation method {c_method}",
                fab_constant.ERROR_INVALID_INPUT,
            )
        if p_name in provided_params:
            parsed_params.append(
                {
                    "dataType": param["dataType"],
                    "name": p_name,
                    "value": provided_params[p_name],
                }
            )
    for param in provided_params:
        if param not in [p["name"] for p in creation_method["parameters"]]:
            c_method = creation_method["name"]
            utils_ui.print_warning(
                f"Parameter {param} is not used by the creation method {c_method} and will be ignored"
            )

    connection_request["connectionDetails"] = {
        "type": con_type,
        "creationMethod": creation_method["name"],
        "parameters": parsed_params,
    }

    # Check that the provided credential type is supported by the connection type
    # Format:
    # "credentialDetails": {
    #   "credentialType": "Basic",
    #   "singleSignOnType": "None",
    #   "connectionEncryption": "NotEncrypted",
    #   "skipTestConnection": false,
    #   "credentials": {
    #     "credentialType": "Basic",
    #     "username": "admin",
    #     "password": "********"
    #   }
    # }
    if not params.get("credentialdetails"):
        raise CustomError(
            "Credential details are required", fab_constant.ERROR_INVALID_INPUT
        )
    provided_cred_type = params.get("credentialdetails").get("type")
    if not provided_cred_type:
        raise CustomError(
            "Credential type is required", fab_constant.ERROR_INVALID_INPUT
        )
    cred_type = next(
        (
            item
            for item in con_type_def["supportedCredentialTypes"]
            if item.lower() == provided_cred_type.lower()
        ),
        None,
    )
    if cred_type is None:
        sup_cred_types = con_type_def["supportedCredentialTypes"]
        raise CustomError(
            f"Invalid credential type. Supoported Credentials for {con_type} are {sup_cred_types}",
            fab_constant.ERROR_INVALID_INPUT,
        )
    provided_cred_params = params.get("credentialdetails", {})
    provided_cred_params.pop("type")
    # Get the single sign on type, use None as default
    singleSignOnType = provided_cred_params.get("singleSignOnType", "None")
    # Remove if present
    if "singleSignOnType" in provided_cred_params:
        provided_cred_params.pop("singleSignOnType")
    # Any as default (first tries Encrypted and fallbacks to NotEncrypted)
    encryption = provided_cred_params.get("connectionEncryption", "Any")
    if "connectionEncryption" in provided_cred_params:
        provided_cred_params.pop("connectionEncryption")
    skipTestConnection = provided_cred_params.get("skipTestConnection", False)
    if "skipTestConnection" in provided_cred_params:
        provided_cred_params.pop("skipTestConnection")

    connection_params = _validate_credential_params(cred_type, provided_cred_params)

    connection_request["credentialDetails"] = {
        "singleSignOnType": singleSignOnType,
        "connectionEncryption": encryption,
        "skipTestConnection": skipTestConnection,
        "credentials": connection_params,
    }
    connection_request["credentialDetails"]["credentials"]["credentialType"] = cred_type

    return connection_request


def find_vnet_subnet(vnet_name, subnet_name) -> tuple:
    args = type("", (), {})()
    subscriptions = subscriptions_api.list_subscriptions_azure(args)
    if subscriptions.status_code != 200:
        raise CustomError("Failed to list subscriptions", fab_constant.ERROR_NOT_FOUND)
    subscriptions = json.loads(subscriptions.text)["value"]
    for sub in subscriptions:
        sub_id = sub["id"].split("/")[-1]
        sub_name = sub["displayName"]
        _args = type("", (), {})()
        _args.subscription_id = sub_id
        vnet_req = vnet_api.list_vnets_azure(_args)
        vnets = json.loads(vnet_req.text)["value"]
        vnet = next(
            (item for item in vnets if item["name"].lower() == vnet_name.lower()),
            None,
        )
        if vnet:
            # Check if the subnet exists
            subnets = vnet["properties"]["subnets"]
            subnet = next(
                (
                    item
                    for item in subnets
                    if item["name"].lower() == subnet_name.lower()
                ),
                None,
            )
        if vnet and subnet:
            # TODO: Add support for adding subnet delegation to Microsoft.PowerPlatform/vnetaccesslinks if missing
            subnet_id = subnet["id"]
            rg_name = subnet_id.split("/")[4]
            return sub_id, rg_name

    return None, None


def lowercase_keys(data):
    if isinstance(data, dict):
        return {k.lower(): lowercase_keys(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [lowercase_keys(item) for item in data]
    else:
        return data


def validate_spark_pool_params(params):
    # Node size options
    allowed_node_sizes = {"small", "medium", "large", "xlarge", "xxlarge"}

    # Validate and set nodesize
    if params.get("nodesize"):
        nodesize = params.get("nodesize").lower()
        if nodesize not in allowed_node_sizes:
            raise CustomError(
                f"Invalid nodesize '{nodesize}'. Allowed values are: {', '.join(allowed_node_sizes)}",
                fab_constant.ERROR_INVALID_INPUT,
            )

    # Validate autoscale
    if params.get("autoscale.maxnodecount") and params.get("autoscale.minnodecount"):
        if int(params.get("autoscale.maxnodecount")) < int(
            params.get("autoscale.minnodecount")
        ):
            raise CustomError(
                "maxNodeCount must be >= minNodeCount",
                fab_constant.ERROR_INVALID_INPUT,
            )


def find_mpe_connection(managed_private_endpoint, targetprivatelinkresourceid):
    args = Namespace()
    args.resource_uri = targetprivatelinkresourceid
    response = mpe_api.list_private_endpoints_by_azure_resource(args)
    if response.status_code == 200:
        connections = json.loads(response.text)["value"]
        ws_id = managed_private_endpoint.get_workspace_id()
        conn_name = f"{ws_id}.{managed_private_endpoint.get_short_name()}"
        # Find the connection that matches the name
        conn = next(
            (
                item
                for item in connections
                if item["properties"]["privateEndpoint"]["id"]
                .lower()
                .split("/")[-1]
                == conn_name.lower()
            ),
            None,
        )
        return conn
    
    return None