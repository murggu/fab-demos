import json
import re
from xml.sax.saxutils import escape

from fabric_cli.core import fab_constant
from fabric_cli.utils.fab_custom_exception import CustomError


def parse_json(args):
    """Helper function to parse the --input argument into a correct json format"""

    # Normalize the content array to a single string without quotes
    normalized_content = " ".join(args.input).strip("\"'")

    if normalized_content.startswith("{") and normalized_content.endswith("}"):
        # Override ' for " to make it a valid JSON
        target_json = json.loads(normalized_content.replace("'", '"'))

        args.target_json = json.dumps(target_json)
        args.input = None


def validate_shortcut_name(name):
    invalid_chars = r"[\"\\:|<>*?.%+]"
    if re.search(invalid_chars, name):
        raise CustomError(
            f"Invalid shortcut name. The name should not include any of the following characters: {escape(invalid_chars)}",
            fab_constant.ERROR_INVALID_PATH,
        )
