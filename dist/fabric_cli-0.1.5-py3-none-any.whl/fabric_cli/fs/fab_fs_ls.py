import json

from fabric_cli.client import fab_api_capacity as capacity_api
from fabric_cli.client import fab_api_connection as connection_api
from fabric_cli.client import fab_api_domain as domain_api
from fabric_cli.client import fab_api_gateway as gateway_api
from fabric_cli.client import fab_api_onelake as onelake_api
from fabric_cli.client import fab_api_workspace as workspace_api
from fabric_cli.core import fab_constant, fab_logger, fab_state_config
from fabric_cli.core.fab_hiearchy import (
    FabricElement,
    Item,
    OneLakeItem,
    Tenant,
    VirtualItemContainer,
    VirtualWorkspace,
    Workspace,
)
from fabric_cli.core.fab_types import VirtualItemContainerType, VirtualWorkspaceType
from fabric_cli.fs import fab_fs as fs
from fabric_cli.utils import fab_cmd_ls_utils as utils_ls
from fabric_cli.utils import fab_mem_store as utils_mem_store
from fabric_cli.utils import fab_ui as utils_ui
from fabric_cli.utils import fab_util as utils
from typing import Any


def exec_command(args, context: FabricElement):

    if isinstance(context, Tenant):
        _ls_workspaces(context, args)
    elif isinstance(context, VirtualWorkspace):
        _ls_virtual_workspace(context, args)
    elif isinstance(context, Workspace):
        _ls_workspace_items(context, args)
    elif isinstance(context, Item):
        _ls_item_folders(context, args)
    elif isinstance(context, OneLakeItem):
        _ls_onelake(context, args)
    elif isinstance(context, VirtualItemContainer):
        _ls_virtual_item_container(context, args)


# Workspaces
def _ls_workspaces(tenant: Tenant, args):
    show_details = bool(args.long)
    show_all = bool(args.all)
    workspaces = utils_mem_store.get_workspaces(tenant)

    if workspaces:
        sorted_workspaces = utils_ls.get_sorted_workspaces(workspaces)

        if show_details:
            capacities, workspaces_details = utils_ls.get_capacities_and_workspaces(
                args
            )
            sorted_workspaces = utils_ls.enrich_workspaces_with_details(
                sorted_workspaces, workspaces_details, capacities
            )

        columns = (
            ["name", "id", "capacityName", "capacityId", "capacityRegion"]
            if show_details
            else ["name"]
        )
        utils_ui.print_entries_unix_style(
            sorted_workspaces, columns, header=show_details
        )

    if show_all or fab_state_config.get_config(fab_constant.FAB_SHOW_HIDDEN) == "true":
        utils_ui.print_grey("------------------------------")
        sorted_vws = sorted(VirtualWorkspaceType, key=lambda vws: vws.value)
        for vws in sorted_vws:
            utils_ui.print_grey(vws.value)


# Virtual Workspaces
def _ls_virtual_workspace(virtual_workspace: VirtualWorkspace, args):
    show_details = bool(args.long)
    match virtual_workspace.get_vws_type():
        case VirtualWorkspaceType.CAPACITY:
            _ls_capacities(virtual_workspace, args, show_details)
        case VirtualWorkspaceType.DOMAIN:
            _ls_domains(virtual_workspace, args, show_details)
        case VirtualWorkspaceType.CONNECTION:
            _ls_connections(virtual_workspace, args, show_details)
        case VirtualWorkspaceType.GATEWAY:
            _ls_gateways(virtual_workspace, args, show_details)
        case _:
            utils_ui.print_grey("Not Supported")


# Virtual Workspace Items - Capacity
def _ls_capacities(vws: VirtualWorkspace, args, show_details):
    capacities = utils_mem_store.get_capacities(vws.get_tenant())
    sorted_capacities = sorted(
        [
            {"name": c.get_name(), "id": c.get_id(), "displayName": c.get_short_name()}
            for c in capacities
        ],
        key=lambda item: item["name"],
    )

    if show_details:
        fab_response = capacity_api.list_capacities(args)
        if fab_response.status_code in {200, 201}:
            _capacities: list = json.loads(fab_response.text)["value"]
            for cap in sorted_capacities:
                capacity_details: dict[str, str] = next(
                    (c for c in _capacities if c["id"] == cap["id"]), {}
                )
                cap["sku"] = capacity_details.get("sku", "Unknown")
                cap["region"] = capacity_details.get("region", "Unknown")
                cap["state"] = capacity_details.get("state", "Unknown")

        # Azure details
        _az_capacities: list = fs._get_all_az_capacities()
        unknown_capacity = {
            "id": "/subscriptions/Unknown/resourceGroups/Unknown/providers/Microsoft.Fabric/capacities/Unknown",
            "properties": {"administration": {"members": []}},
            "tags": "",
        }
        for cap in sorted_capacities:
            az_cap_details: dict = next(
                (c for c in _az_capacities if c["name"] == cap["displayName"]),
                unknown_capacity,
            )
            # id is in the format /subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-name/providers/Microsoft.Fabric/capacities/capacity-name
            cap["subscriptionId"] = az_cap_details["id"].split("/")[2]
            cap["resourceGroup"] = az_cap_details["id"].split("/")[4]
            cap["admins"] = az_cap_details["properties"]["administration"]["members"]
            cap["tags"] = str(az_cap_details["tags"])

    columns = (
        [
            "name",
            "id",
            "sku",
            "region",
            "state",
            "subscriptionId",
            "resourceGroup",
            "admins",
            "tags",
        ]
        if show_details
        else ["name"]
    )
    utils_ui.print_entries_unix_style(sorted_capacities, columns, header=show_details)


# Virtual Workspace Items - Gateway
def _ls_gateways(vws: VirtualWorkspace, args, show_details):
    _base_cols = ["name", "id"]
    _details_cols = ["type", "capacityId", "numberOfMemberGateways", "version"]
    gateways = utils_mem_store.get_gateways(vws.get_tenant())
    sorted_gateways = sorted(
        [
            {"name": g.get_name(), "id": g.get_id(), "displayName": g.get_short_name()}
            for g in gateways
        ],
        key=lambda item: item["name"],
    )

    if show_details:
        fab_response = gateway_api.list_gateways(args)
        if fab_response.status_code in {200, 201}:
            _gateways: list = json.loads(fab_response.text)["value"]
            for gateway in sorted_gateways:
                gateway_details: dict[str, str] = next(
                    (c for c in _gateways if c["id"] == gateway["id"]), {}
                )
                for col in _details_cols:
                    gateway[col] = gateway_details.get(col, "Unknown")

    columns = _base_cols + _details_cols if show_details else ["name"]
    utils_ui.print_entries_unix_style(sorted_gateways, columns, header=show_details)


# Virtual Workspace Items - Domain
def _ls_domains(vws: VirtualWorkspace, args, show_details):
    fab_logger.log_warning(fab_constant.WARNING_FABRIC_ADMIN_ROLE)
    domains = utils_mem_store.get_domains(vws.get_tenant())
    sorted_domains = sorted(
        [{"name": d.get_name(), "id": d.get_id()} for d in domains],
        key=lambda item: item["name"],
    )

    base_cols = ["name"]

    if show_details:
        domains_detail_cols = [
            "id",
            "contributorsScope",
            "description",
            "parentDomainId",
        ]
        fab_response = domain_api.list_domains(args)
        if fab_response.status_code in {200, 201}:
            _domains: list = json.loads(fab_response.text)["domains"]
            for domain in sorted_domains:
                domain_details: dict[str, str] = next(
                    (d for d in _domains if d["id"] == domain["id"]), {}
                )
                for col in domains_detail_cols:
                    domain[col] = domain_details.get(col, "Unknown")

                # enrich with parentDomainName
                domain["parentDomainName"] = utils_ls.get_domain_name_by_id(
                    domains, domain.get("parentDomainId")
                )
        domains_detail_cols.insert(3, "parentDomainName")

    columns = base_cols + domains_detail_cols if show_details else base_cols
    utils_ui.print_entries_unix_style(sorted_domains, columns, header=show_details)


# Virtual Workspace Items - Connection
def _ls_connections(vws: VirtualWorkspace, args, show_details):
    _base_cols = ["name", "id"]
    _details_cols = {
        # "connectionDetails",
        "connectionDetails.type": "type",
        "connectivityType": "connectivityType",
        # "credentialDetails",
        "gatewayName": "gatewayName",
        "gatewayId": "gatewayId",
        "privacyLevel": "privacyLevel",
    }
    connections = utils_mem_store.get_connections(vws.get_tenant())
    sorted_connections = sorted(
        [
            {"name": c.get_name(), "id": c.get_id(), "displayName": c.get_short_name()}
            for c in connections
        ],
        key=lambda item: item["name"],
    )

    if show_details:
        fab_response = connection_api.list_connections(args)
        if fab_response.status_code in {200, 201}:
            _connections: list = json.loads(fab_response.text)["value"]
            for connection in sorted_connections:
                connection_details: dict[str, Any] = next(
                    (c for c in _connections if c["id"] == connection["id"]), {}
                )
                for col, alias in _details_cols.items():
                    cols = col.split(".")
                    # Loop through cols minus the last one
                    if len(cols) > 1:
                        _value: dict[str, Any] = connection_details
                        for i in range(len(cols) - 1):
                            _value = _value.get(cols[i], {})
                        connection[alias] = _value.get(cols[-1], "Unknown")
                    else:
                        connection[alias] = connection_details.get(col, "Unknown")

        _gateways = utils_mem_store.get_gateways(vws.get_tenant())
        for connection in sorted_connections:
            gateway_id = connection.get("gatewayId")
            gateway_name = next(
                (g.get_name() for g in _gateways if g.get_id() == gateway_id), "Unknown"
            )
            connection["gatewayName"] = gateway_name

    columns = _base_cols + list(_details_cols.values()) if show_details else ["name"]
    utils_ui.print_entries_unix_style(sorted_connections, columns, header=show_details)


# Items
def _ls_workspace_items(workspace: Workspace, args):
    show_details = bool(args.long)
    show_all = bool(args.all)
    ws_items: list[Item] = utils_mem_store.get_workspace_items(workspace)

    if ws_items:
        sorted_items = sorted(
            [{"name": item.get_name(), "id": item.get_id()} for item in ws_items],
            key=lambda item: item["name"],
        )

        columns = ["name", "id"] if show_details else ["name"]
        utils_ui.print_entries_unix_style(sorted_items, columns, header=show_details)

    if show_all or fab_state_config.get_config(fab_constant.FAB_SHOW_HIDDEN) == "true":
        utils_ui.print_grey("------------------------------")
        sorted_vic = sorted(VirtualItemContainerType, key=lambda vic: vic.value)
        for vic in sorted_vic:
            utils_ui.print_grey(vic.value)


# Virtual Items
def _ls_virtual_item_container(virtual_item_container: VirtualItemContainer, args):
    show_details = bool(args.long)
    match virtual_item_container.get_vic_type():
        case VirtualItemContainerType.SPARK_POOL:
            _ls_spark_pools(virtual_item_container, args, show_details)
        case VirtualItemContainerType.MANAGED_IDENTITY:
            _ls_managed_identities(virtual_item_container, args, show_details)
        case VirtualItemContainerType.MANAGED_PRIVATE_ENDPOINT:
            _ls_managed_private_endpoints(virtual_item_container, args, show_details)
        case VirtualItemContainerType.EXTERNAL_DATA_SHARE:
            _ls_external_data_shares(virtual_item_container, args, show_details)
        case _:
            utils_ui.print_grey("Not Supported")


# Virtual Items - Spark Pool
def _ls_spark_pools(vic: VirtualItemContainer, args, show_details):
    spark_pools = utils_mem_store.get_spark_pools(vic)

    if spark_pools:
        sorted_spark_pools = sorted(
            [{"name": sp.get_name(), "id": sp.get_id()} for sp in spark_pools],
            key=lambda item: item["name"],
        )
        base_cols = ["name"]

        if show_details:
            sp_detail_cols = [
                "id",
                "nodeFamily",
                "nodeSize",
                "type",
                "autoScale",
                "dynamicExecutorAllocation",
            ]
            response = workspace_api.ls_workspace_spark_pools(
                args, vic.get_workspace_id()
            )
            if response.status_code in {200, 201}:
                _spark_pools: list = json.loads(response.text)["value"]
                for spark_pool in sorted_spark_pools:
                    sp_details: dict[str, str] = next(
                        (c for c in _spark_pools if c["id"] == spark_pool["id"]), {}
                    )
                    for col in sp_detail_cols:
                        spark_pool[col] = sp_details.get(col, "Unknown")

        columns = base_cols + sp_detail_cols if show_details else base_cols
        utils_ui.print_entries_unix_style(
            sorted_spark_pools, columns, header=show_details
        )


# Virtual Items - Managed Identity
def _ls_managed_identities(vic: VirtualItemContainer, args, show_details):
    managed_identities = utils_mem_store.get_managed_identities(vic)

    if managed_identities:
        sorted_managed_identities = sorted(
            [{"name": mi.get_name(), "id": mi.get_id()} for mi in managed_identities],
            key=lambda item: item["name"],
        )
        base_cols = ["name"]
        if show_details:
            mi_detail_cols = ["servicePrincipalId", "applicationId"]

            args.ws_id = vic.get_workspace_id()
            response = workspace_api.get_workspace(args)
            if response.status_code in {200, 201}:
                _managed_identities: list = [
                    json.loads(response.text)["workspaceIdentity"]
                ]
                for managed_identity in sorted_managed_identities:
                    mi_details: dict[str, str] = next(
                        (
                            c
                            for c in _managed_identities
                            if c["servicePrincipalId"] == managed_identity["id"]
                        ),
                        {},
                    )
                    for col in mi_detail_cols:
                        managed_identity[col] = mi_details.get(col, "Unknown")

        columns = base_cols + mi_detail_cols if show_details else base_cols
        utils_ui.print_entries_unix_style(
            sorted_managed_identities, columns, header=show_details
        )


# Virtual Item - Managed Private Endpoint
def _ls_managed_private_endpoints(vic: VirtualItemContainer, args, show_details):
    mngd_pvt_endpoints = utils_mem_store.get_managed_private_endpoints(vic)

    if mngd_pvt_endpoints:
        sorted_managed_private_endpoints = sorted(
            [
                {"name": mpe.get_name(), "id": mpe.get_id()}
                for mpe in mngd_pvt_endpoints
            ],
            key=lambda item: item["name"],
        )
        base_cols = ["name"]
        if show_details:
            mpe_detail_cols = [
                "id",
                "connectionState",
                "provisioningState",
                "targetPrivateLinkResourceId",
                "targetSubresourceType",
            ]

            args.ws_id = vic.get_workspace_id()
            response = workspace_api.ls_workspace_managed_private_endpoints(args)
            if response.status_code in {200, 201}:
                _managed_private_endpoints: list = json.loads(response.text)["value"]
                for managed_private_endpoint in sorted_managed_private_endpoints:
                    mpe_details: dict[str, str] = next(
                        (
                            c
                            for c in _managed_private_endpoints
                            if c["id"] == managed_private_endpoint["id"]
                        ),
                        {},
                    )
                    for col in mpe_detail_cols:
                        managed_private_endpoint[col] = mpe_details.get(col, "Unknown")

        columns = base_cols + mpe_detail_cols if show_details else base_cols
        utils_ui.print_entries_unix_style(
            sorted_managed_private_endpoints, columns, header=show_details
        )


# Virtual Item - External Data Share
def _ls_external_data_shares(vic: VirtualItemContainer, args, show_details):
    external_data_shares = utils_mem_store.get_external_data_shares(vic.get_parent())

    if external_data_shares:
        sorted_external_data_shares = sorted(
            [
                {
                    "name": eds.get_name(),
                    "id": eds.get_id(),
                    "status": eds.get_status(),
                    "itemId": eds.get_item_id(),
                }
                for eds in external_data_shares
            ],
            key=lambda item: item["name"],
        )

        base_cols = ["name"]

        should_filter_out_revoked_eds = not show_details
        if show_details:
            eds_detail_cols = [
                "id",
                "status",
                "itemId",
                # "creatorPrincipal",
                # "expirationTimeUtc",
                # "invitationUrl",
                # "paths",
                # "recipient",
                # "workspaceId",
            ]
            eds_detail_col_enrich = "itemName"

            for external_data_share in sorted_external_data_shares:
                item_name = utils.get_item_name_from_eds_name(
                    external_data_share.get("name")
                )
                external_data_share[eds_detail_col_enrich] = item_name

        if should_filter_out_revoked_eds:
            sorted_external_data_shares = [
                eds
                for eds in sorted_external_data_shares
                if not eds["status"] == "Revoked"
            ]

        columns = (
            base_cols + eds_detail_cols + [eds_detail_col_enrich]
            if show_details
            else base_cols
        )
        utils_ui.print_entries_unix_style(
            sorted_external_data_shares, columns, header=show_details
        )


# Onelake - Folder
def _ls_item_folders(item: Item, args):

    show_details = bool(args.long)

    args.directory = item.get_path_id().strip("/")
    response = onelake_api.list_tables_files(args)

    if response.status_code in (200, 201):
        response_data = json.loads(response.text)
        paths = response_data.get("paths", [])

        for entry in paths:
            entry["name"] = (
                entry["name"].split("/")[1] if "/" in entry["name"] else entry["name"]
            )

        columns = ["permissions", "lastModified", "name"] if show_details else ["name"]
        utils_ui.print_entries_unix_style(paths, columns, header=show_details)


# Onelake - SubFolder, Shortcut, File
def _ls_onelake(onelake: OneLakeItem, args):

    show_details = bool(args.long)

    local_path = utils.remove_dot_suffix(onelake.get_local_path())
    workspace_id = onelake.get_workspace_id()
    item_id = onelake.get_item_id()

    args.directory = f"{workspace_id}/?recursive=false&resource=filesystem&directory={item_id}/{local_path}&getShortcutMetadata=true"
    response = onelake_api.list_tables_files_recursive(args)

    if response.status_code in {200, 201}:
        if response.text:
            response_data = json.loads(response.text)
            paths = response_data.get("paths", [])

            if paths:
                for entry in paths:
                    utils_ls.update_entry_name_and_type(entry, local_path)

                columns = (
                    ["permissions", "lastModified", "name", "type"]
                    if show_details
                    else ["name"]
                )
                utils_ui.print_entries_unix_style(paths, columns, header=show_details)
            else:
                utils_ui.print_grey("[]")
