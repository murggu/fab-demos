import re

from fabric_cli.client import fab_api_onelake as onelake_api
from fabric_cli.core import fab_constant
from fabric_cli.core.fab_hiearchy import (
    FabricElement,
    Item,
    ItemType,
    OneLakeItem,
    Workspace,
)
from fabric_cli.fs import fab_fs_mv as fs_mv
from fabric_cli.utils import fab_ui as utils_ui
from fabric_cli.utils import fab_util as utils
from fabric_cli.utils.fab_custom_exception import CustomError


def exec_command(args, from_context: FabricElement, to_context: FabricElement):
    args.from_path, args.to_path = from_context.get_path(), to_context.get_path()

    # Source and target items must be same types
    if from_context.get_type() != to_context.get_type():
        raise CustomError(
            fab_constant.WARNING_INVALID_PATHS, fab_constant.ERROR_INVALID_INPUT
        )

    # Workspaces
    if isinstance(from_context, Workspace) and isinstance(to_context, Workspace):
        fs_mv._move_workspace_items_if_types_match(
            from_context, to_context, args, delete_from_item=False
        )

    # Items
    elif isinstance(from_context, Item) and isinstance(to_context, Item):
        fs_mv._move_item_if_types_match(
            from_context, to_context, args, delete_from_item=False
        )

    # OneLake
    elif isinstance(from_context, OneLakeItem) and isinstance(to_context, OneLakeItem):
        _copy_onelake(from_context, to_context, args)
    else:
        raise CustomError(
            fab_constant.WARNING_INVALID_PATHS, fab_constant.ERROR_NOT_SUPPORTED
        )


# OneLake - Files and Folders
def _copy_onelake(from_context: OneLakeItem, to_context: OneLakeItem, args):

    # Only supported in Lakehouse
    item: Item = from_context.get_parent()
    item_type = item.get_item_type()

    if item_type != ItemType.LAKEHOUSE:
        raise CustomError(
            fab_constant.WARNING_MKDIR_INVALID_ONELAKE, fab_constant.ERROR_NOT_SUPPORTED
        )

    from_path_id, from_path_name, to_path_id, to_path_name = (
        utils.obtain_id_names_for_onelake(from_context, to_context)
    )
    args.from_path, args.to_path = from_path_id, to_path_id

    # Check if move paths provide /Files
    pattern = r"^/?Files(?:/[^/]+)*$"
    from_local_path = utils.remove_dot_suffix(from_context.get_local_path())
    to_local_path = utils.remove_dot_suffix(to_context.get_local_path())

    if re.match(pattern, from_local_path) and re.match(pattern, to_local_path):

        response = onelake_api.get_properties(args)
        if response.headers["x-ms-resource-type"] == "directory":
            raise CustomError(
                "Recursive copy not supported", fab_constant.ERROR_NOT_SUPPORTED
            )
        elif response.headers["x-ms-resource-type"] == "file":

            utils_ui.print_grey(f"Copying '{from_path_name}' → '{to_path_name}'...")
            response_get = onelake_api.get(args)

            if response_get.status_code not in (200, 201):
                raise CustomError("Source file not found", fab_constant.ERROR_NOT_FOUND)

            content = response_get.text
            if not content:
                raise CustomError(
                    "Invalid copy, source is empty", fab_constant.ERROR_INVALID_INPUT
                )

            response = onelake_api.touch_file(args)
            if response.status_code == 201:
                onelake_api.append_file(args, content, 0)
                onelake_api.flush_file(args, len(content))
                utils_ui.print_done("Done")
    else:
        raise CustomError(
            "Invalid paths. Only supported within /Files",
            fab_constant.ERROR_NOT_SUPPORTED,
        )
