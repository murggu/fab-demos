import os
import re

from fabric_cli.client import fab_api_capacity as capacity_api
from fabric_cli.client import fab_api_connection as connection_api
from fabric_cli.client import fab_api_domain as domain_api
from fabric_cli.client import fab_api_gateway as gateway_api
from fabric_cli.client import fab_api_item as item_api
from fabric_cli.client import fab_api_managedIdentity as managed_identity_api
from fabric_cli.client import (
    fab_api_managedPrivateEndpoint as managed_private_endpoint_api,
)
from fabric_cli.client import fab_api_onelake as onelake_api
from fabric_cli.client import fab_api_shortcuts as shortcut_api
from fabric_cli.client import fab_api_sparkpool as sparkpool_api
from fabric_cli.client import fab_api_workspace as workspace_api
from fabric_cli.core import fab_constant, fab_logger
from fabric_cli.core import fab_state_config as fab_state_config
from fabric_cli.core.fab_commands import Command
from fabric_cli.core.fab_context import Context
from fabric_cli.core.fab_hiearchy import (
    Item,
    OneLakeItem,
    VirtualItem,
    ItemType,
    VirtualWorkspaceItem,
    Workspace,
)
from fabric_cli.core.fab_types import (
    OneLakeItemType,
    VirtualItemType,
    VirtualWorkspaceItemType,
)
from fabric_cli.fs import fab_fs as fs
from fabric_cli.fs import fab_fs_cd as fs_cd
from fabric_cli.utils import fab_mem_store as utils_mem_store
from fabric_cli.utils import fab_ui as utils_ui
from fabric_cli.utils import fab_util as utils
from fabric_cli.utils.fab_custom_exception import CustomError


def exec_command(args, context):
    force_delete = bool(args.force)

    if isinstance(context, Workspace):
        _rm_workspace(context, args, force_delete)
    elif isinstance(context, Item):
        _rm_item(context, args, force_delete)
    elif isinstance(context, VirtualItem):
        _rm_virtual_item(context, args, force_delete)
    elif isinstance(context, VirtualWorkspaceItem):
        _rm_virtual_ws_item(context, args, force_delete)
    elif isinstance(context, OneLakeItem):
        if context.get_nested_type() == OneLakeItemType.SHORTCUT:
            _rm_onelake(context, args, force_delete)
        else:
            raise CustomError("Not supported", fab_constant.ERROR_NOT_SUPPORTED)

    if Context().get_context().is_ascendent(context):
        fs_cd.exec_command(args, context.get_parent())


# Workspaces
def _rm_workspace(workspace: Workspace, args, force_delete):

    args.ws_id = workspace.get_id()
    args.name = workspace.get_name()

    ws_items: list[Item] = utils_mem_store.get_workspace_items(workspace)

    # Empty workspace
    if not ws_items and not force_delete:
        raise CustomError(
            "Empty workspace. Use -f to remove it",
            fab_constant.ERROR_NOT_SUPPORTED,
        )

    # Filter items supporting rm
    supported_items = []
    for item in ws_items:
        try:
            if item.check_command_support(Command.FS_RM):
                supported_items.append(item)
        except Exception as e:
            pass

    if force_delete:
        utils_ui.print_grey(f"This will delete {len(ws_items)} underlying items")

        if workspace_api.delete_workspace(args, force_delete):
            # Remove from mem_store
            utils_mem_store.delete_workspace_from_cache(workspace)
    else:
        # Some items don't support delete
        if not supported_items:
            raise CustomError(
                "Items can't be deleted. Use -f to remove the workspace",
                fab_constant.ERROR_NOT_SUPPORTED,
            )
        else:
            sorted_items = [item for item in ws_items]
            sorted_items = sorted(sorted_items, key=lambda item: item.get_name())

            names = [item.get_name() for item in sorted_items]
            selected_items = utils_ui.prompt_select_items(
                "Select the items to delete:", names
            )
            if selected_items:
                for item in selected_items:
                    utils_ui.print_grey(item)
                utils_ui.print_grey("------------------------------")
                filtered_items = [
                    item for item in sorted_items if item.get_name() in selected_items
                ]
                if utils_ui.prompt_confirm():

                    deleted_items = 0

                    for item in filtered_items:
                        args.id = item.get_id()
                        args.name = item.get_name()
                        args.item_type = str(item.get_type())

                        # Reset args for subsequent calls
                        args.uri = None
                        args.method = None

                        if item_api.delete_item(
                            args, bypass_confirmation=True, debug=False
                        ):
                            utils_ui.print_done(f"'{args.name}' deleted")
                            deleted_items = deleted_items + 1

                            # Remove from mem_store
                            utils_mem_store.delete_item_from_cache(item)

                    utils_ui.print("")
                    utils_ui.print_done(f"{deleted_items} items deleted successfully")


# Items
def _rm_item(item: Item, args, force_delete):

    args.ws_id = item.get_workspace_id()
    args.id = item.get_id()
    args.name = item.get_name()
    args.item_type = item.get_type().value

    if item_api.delete_item(args, force_delete):
        # Remove from mem_store
        utils_mem_store.delete_item_from_cache(item)


# Virtual Item
def _rm_virtual_item(virtual_item: VirtualItem, args, force_delete):

    if virtual_item.get_item_type() == VirtualItemType.SPARK_POOL:
        args.ws_id = virtual_item.get_workspace_id()
        args.id = virtual_item.get_id()
        args.name = virtual_item.get_name()

        if sparkpool_api.delete_spark_pool(args, force_delete):
            # Remove from mem_store
            utils_mem_store.delete_spark_pool_from_cache(virtual_item)
        return

    if virtual_item.get_item_type() == VirtualItemType.MANAGED_IDENTITY:
        if (
            virtual_item.get_short_name()
            != virtual_item.get_workspace().get_short_name()
        ):
            fab_logger.log_warning(
                "A valid ManagedIdentity matching the Workspace name must be provided"
            )
            return

        args.ws_id = virtual_item.get_workspace_id()
        args.id = virtual_item.get_id()
        args.name = virtual_item.get_name()

        if managed_identity_api.deprovision_managed_identity(args, force_delete):
            utils_mem_store.delete_managed_identity_from_cache(virtual_item)
        return

    if virtual_item.get_item_type() == VirtualItemType.MANAGED_PRIVATE_ENDPOINT:
        args.ws_id = virtual_item.get_workspace_id()
        args.id = virtual_item.get_id()
        args.name = virtual_item.get_name()

        if managed_private_endpoint_api.delete_managed_private_endpoint(
            args, force_delete
        ):
            # Remove from mem_store
            utils_mem_store.delete_managed_private_endpoint_from_cache(virtual_item)
        return

    if virtual_item.get_item_type() == VirtualItemType.EXTERNAL_DATA_SHARE:
        args.ws_id = virtual_item.get_workspace_id()
        args.id = virtual_item.get_id()
        args.name = virtual_item.get_name()

        item_name = utils.get_item_name_from_eds_name(virtual_item.get_name())
        args.item_id = utils_mem_store.get_item_id(
            virtual_item.get_workspace(), item_name
        )

        if item_api.revoke_item_external_data_share(args, force_delete):
            # Remove from mem_store
            utils_mem_store.delete_external_data_share_from_cache(virtual_item)
        return

    fab_logger.log_warning("Deletion is not supported", args.command_path)


# Virtual Workspace Item
def _rm_virtual_ws_item(virtual_ws_item: VirtualWorkspaceItem, args, force_delete):

    if virtual_ws_item.get_item_type() == VirtualWorkspaceItemType.CAPACITY:
        fs.fill_capacity_args(virtual_ws_item, args)

        if capacity_api.delete_capacity(args, force_delete):
            # Remove from mem_store
            utils_mem_store.delete_capacity_from_cache(virtual_ws_item)

    elif virtual_ws_item.get_item_type() == VirtualWorkspaceItemType.CONNECTION:
        args.id = virtual_ws_item.get_id()
        args.name = virtual_ws_item.get_name()
        if connection_api.delete_connection(args, force_delete):
            # Remove from mem_store
            utils_mem_store.delete_connection_from_cache(virtual_ws_item)

    elif virtual_ws_item.get_item_type() == VirtualWorkspaceItemType.GATEWAY:
        args.id = virtual_ws_item.get_id()
        args.name = virtual_ws_item.get_name()
        if gateway_api.delete_gateway(args, force_delete):
            # Remove from mem_store
            utils_mem_store.delete_gateway_from_cache(virtual_ws_item)

    elif virtual_ws_item.get_item_type() == VirtualWorkspaceItemType.DOMAIN:
        _rm_domain(virtual_ws_item, args, force_delete)
        return

    else:
        fab_logger.log_warning("Deletion is not supported", args.command_path)


def _rm_domain(virtual_ws_item: VirtualWorkspaceItem, args, force_delete):
    fab_logger.log_warning(fab_constant.WARNING_FABRIC_ADMIN_ROLE)
    args.id = virtual_ws_item.get_id()
    args.name = virtual_ws_item.get_name()
    if domain_api.delete_domain(args, force_delete):
        # Remove from mem_store
        utils_mem_store.delete_domain_from_cache(virtual_ws_item)
    return


# OneLake - Shortcut, File and Folder
def _rm_onelake(onelake: OneLakeItem, args, force_delete, debug=True):

    # Only supported in Lakehouse
    item: Item = onelake.get_parent()
    item_type = item.get_item_type()

    if item_type != ItemType.LAKEHOUSE:
        raise CustomError(
            fab_constant.WARNING_MKDIR_INVALID_ONELAKE, fab_constant.ERROR_NOT_SUPPORTED
        )

    # Remove shortcut
    # if onelake.get_nested_type() == OneLakeItemType.SHORTCUT:
    #     args.ws_id = onelake.get_workspace_id()
    #     args.id = onelake.get_item_id()
    #     args.path, name = os.path.split(onelake.get_local_path().rstrip("/"))
    #     args.sc_name = utils.remove_dot_suffix(name)  # shortcut name without .Shortcut
    #     args.name = name  # the name that is displayed in the UI

    #     shortcut_api.delete_shortcut(args, force_delete, debug)
    #     return

    # Remove file or folder
    path_name = utils.process_nargs(args.path)
    path_id = onelake.get_path_id().strip("/")
    path_id = utils.remove_dot_suffix(path_id)

    local_path = utils.remove_dot_suffix(onelake.get_local_path())

    # Only supported in /Files
    pattern = r"^/?Files(?:/[^/]+)*$"
    error_message_path = "/Files"

    if onelake.get_nested_type() == OneLakeItemType.SHORTCUT:
        pattern = r"^/?(?:Files|Tables)(?:/[^/]+)*$"
        error_message_path = "/Files and Tables"

    if re.match(pattern, local_path):
        args.directory = path_id
        args.name = path_name

        onelake_api.delete_dir(args, force_delete, debug)
    else:
        raise CustomError(
            f"Invalid paths. Only supported within {error_message_path}",
            fab_constant.ERROR_NOT_SUPPORTED,
        )
