import json

from fabric_cli.client import fab_api_item as item_api
from fabric_cli.core import fab_constant, fab_logger
from fabric_cli.core.fab_commands import Command
from fabric_cli.core.fab_hiearchy import Item
from fabric_cli.core.fab_types import ItemType
from fabric_cli.utils import fab_mem_store as utils_mem_store
from fabric_cli.utils import fab_storage as utils_storage
from fabric_cli.utils import fab_ui as utils_ui
from fabric_cli.utils import fab_util as utils
from fabric_cli.utils import fab_cmd_import_utils as utils_import
from fabric_cli.utils.fab_custom_exception import CustomError


def exec_command(args, context):

    args.input = utils.process_nargs(args.input)

    if isinstance(context, Item):
        _import_item(context, args)


# Items
def _import_item(item: Item, args):

    if not item.check_command_support(Command.FS_IMPORT):
        raise CustomError(
            f"'{item.get_name()}' not supported for import/export",
            fab_constant.ERROR_NOT_SUPPORTED,
        )

    # Validate --format
    _input_format = None
    if args.format:
        _input_format = args.format
        if _input_format not in (".py", ".ipynb"):
            raise CustomError(
                "Invalid format. Only '.py' and '.ipynb' are supported.",
                fab_constant.ERROR_INVALID_INPUT,
            )

    args.ws_id = item.get_workspace_id()
    input_path = utils_storage.get_import_path(args.input)

    if input_path["type"] == "lakehouse":
        raise CustomError("Import from Lakehouse/Files not supported")

    if args.force or utils_ui.prompt_confirm():

        # Check first if an item exists
        item_exists = item.get_id() is not None
        _input_path = input_path["path"]

        # Get the payload
        payload = utils_import.get_payload_for_item_type(
            _input_path, item, _input_format
        )

        if item.get_item_type() == ItemType.REPORT:
            # TODO byPath to byConnection magic and logicalIds (all items)
            pass

        if item_exists:
            fab_logger.log_warning("An item with the same name exists")

            # Update
            if args.force or utils_ui.prompt_confirm("Overwrite?"):
                args.id = item.get_id()

                utils_ui.print_grey(
                    f"Importing (update) '{_input_path}' → '{item.get_path()}'..."
                )

                definition_payload = json.dumps(
                    {
                        "definition": payload["definition"],
                    }
                )

                response = item_api.update_item_definition(
                    args, payload=definition_payload
                )
                utils_ui.print_done(f"'{item.get_name()}' imported")
        else:
            _payload = json.dumps(payload)

            # Create
            utils_ui.print_grey(f"Importing '{_input_path}' → '{item.get_path()}'...")
            response = item_api.create_item(args, payload=_payload)

            if response.status_code in (200, 201):
                utils_ui.print_done(f"'{item.get_name()}' imported")
                data = json.loads(response.text)
                item._id = data["id"]

        # Add to mem_store
        utils_mem_store.upsert_item_to_cache(item)
