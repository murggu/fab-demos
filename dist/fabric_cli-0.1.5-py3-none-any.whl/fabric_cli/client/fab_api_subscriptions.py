from fabric_cli.client import fab_api_client as fabric_api


def list_subscriptions_azure(args):
    """https://learn.microsoft.com/en-us/rest/api/resources/subscriptions/list?view=rest-resources-2022-12-01&tabs=HTTP"""

    args.audience = "azure"
    args.uri = "subscriptions?api-version=2022-12-01"
    args.method = "get"

    return fabric_api.do_request(args)
