from fabric_cli.client import fab_api_client as fabric_api
from fabric_cli.client import fab_api_utils as api_utils


def list_capacities(args):
    """https://learn.microsoft.com/en-us/rest/api/fabric/core/capacities/list-capacities?tabs=HTTP"""

    args.uri = "capacities"
    args.method = "get"

    return fabric_api.do_request(args)


def list_capacities_azure(args):
    """https://learn.microsoft.com/en-us/rest/api/microsoftfabric/fabric-capacities/list-by-subscription?view=rest-microsoftfabric-2023-11-01&tabs=HTTP"""

    subscription_id = args.subscription_id
    args.audience = "azure"
    uri = f"subscriptions/{subscription_id}/providers/Microsoft.Fabric/capacities"
    api_version = api_utils.get_api_version(uri)
    args.uri = f"{uri}?api-version={api_version}"
    args.method = "get"

    return fabric_api.do_request(args)


def create_capacity(args, payload):
    """https://learn.microsoft.com/en-us/rest/api/microsoftfabric/fabric-capacities/create-or-update?view=rest-microsoftfabric-2023-11-01&tabs=HTTP"""

    args.audience = "azure"
    uri = _get_capacity_uri(args)
    api_version = api_utils.get_api_version(uri)
    args.uri = f"{uri}?api-version={api_version}"
    args.method = "put"

    return fabric_api.do_request(args, data=payload)


def delete_capacity(args, bypass_confirmation=False, debug=True):
    """https://learn.microsoft.com/en-us/rest/api/microsoftfabric/fabric-capacities/delete?view=rest-microsoftfabric-2023-11-01&tabs=HTTP"""

    args.audience = "azure"
    uri = _get_capacity_uri(args)
    api_version = api_utils.get_api_version(uri)
    args.uri = f"{uri}?api-version={api_version}"
    args.method = "delete"

    return api_utils.delete_resource(args, bypass_confirmation, debug)


def get_capacity(args):
    """https://learn.microsoft.com/en-us/rest/api/microsoftfabric/fabric-capacities/get?view=rest-microsoftfabric-2023-11-01&tabs=HTTP"""

    args.audience = "azure"
    uri = _get_capacity_uri(args)
    api_version = api_utils.get_api_version(uri)
    args.uri = f"{uri}?api-version={api_version}"
    args.method = "get"

    return fabric_api.do_request(args)


def update_capacity(args, payload):
    """https://learn.microsoft.com/en-us/rest/api/microsoftfabric/fabric-capacities/update?view=rest-microsoftfabric-2023-11-01&tabs=HTTP"""

    args.audience = "azure"
    uri = _get_capacity_uri(args)
    api_version = api_utils.get_api_version(uri)
    args.uri = f"{uri}?api-version={api_version}"
    args.method = "patch"

    return fabric_api.do_request(args, data=payload)


def resume_capacity(args, bypass_confirmation=False, debug=True):
    """https://learn.microsoft.com/en-us/rest/api/microsoftfabric/fabric-capacities/resume?view=rest-microsoftfabric-2023-11-01&tabs=HTTP"""

    args.audience = "azure"
    uri = _get_capacity_uri(args)
    api_version = api_utils.get_api_version(uri)
    args.uri = f"{_get_capacity_uri(args)}/resume?api-version={api_version}"
    args.method = "post"

    return api_utils.start_resource(args, bypass_confirmation, debug)


def suspend_capacity(args, bypass_confirmation=False, debug=True):
    """https://learn.microsoft.com/en-us/rest/api/microsoftfabric/fabric-capacities/suspend?view=rest-microsoftfabric-2023-11-01&tabs=HTTP"""

    args.audience = "azure"
    uri = _get_capacity_uri(args)
    api_version = api_utils.get_api_version(uri)
    args.uri = f"{uri}/suspend?api-version={api_version}"
    args.method = "post"

    return api_utils.stop_resource(args, bypass_confirmation, debug)


# Utils
def _get_capacity_uri(args):
    subscription_id = args.subscription_id
    resource_group_name = args.resource_group_name
    # Remove the .capacity suffix if it exists
    name = args.name[:-9] if args.name.lower().endswith(".capacity") else args.name
    return f"subscriptions/{subscription_id}/resourceGroups/{resource_group_name}/providers/Microsoft.Fabric/capacities/{name}"
