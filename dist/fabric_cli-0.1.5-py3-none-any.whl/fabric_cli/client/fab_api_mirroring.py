from fabric_cli.client import fab_api_client as fabric_api
from fabric_cli.client import fab_api_utils as api_utils


def get_mirroring_status(args):
    """https://learn.microsoft.com/en-us/rest/api/fabric/mirroreddatabase/mirroring/get-mirroring-status?tabs=HTTP"""

    ws_id = args.ws_id
    db_id = args.id
    args.uri = f"workspaces/{ws_id}/mirroredDatabases/{db_id}/getMirroringStatus"
    args.method = "post"

    return fabric_api.do_request(args)


def get_table_mirroring_status(args):
    """https://learn.microsoft.com/en-us/rest/api/fabric/mirroreddatabase/mirroring/get-tables-mirroring-status?tabs=HTTP"""

    ws_id = args.ws_id
    db_id = args.id
    args.uri = f"workspaces/{ws_id}/mirroredDatabases/{db_id}/getTablesMirroringStatus"
    args.method = "post"

    return fabric_api.do_request(args)


def start_mirorring(args, bypass_confirmation=False, debug=True):
    """https://learn.microsoft.com/en-us/rest/api/fabric/mirroreddatabase/mirroring/start-mirroring?tabs=HTTP"""

    ws_id = args.ws_id
    db_id = args.id
    args.uri = f"workspaces/{ws_id}/mirroredDatabases/{db_id}/startMirroring"
    args.method = "post"

    return api_utils.start_resource(args, bypass_confirmation, debug)


def stop_mirorring(args, bypass_confirmation=False, debug=True):
    """https://learn.microsoft.com/en-us/rest/api/fabric/mirroreddatabase/mirroring/stop-mirroring?tabs=HTTP"""

    ws_id = args.ws_id
    db_id = args.id
    args.uri = f"workspaces/{ws_id}/mirroredDatabases/{db_id}/stopMirroring"
    args.method = "post"

    return api_utils.stop_resource(args, bypass_confirmation, debug)
