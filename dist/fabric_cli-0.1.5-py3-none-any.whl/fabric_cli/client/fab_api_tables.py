from fabric_cli.client import fab_api_client as fabric_api


def list_tables(args):
    """https://learn.microsoft.com/en-us/rest/api/fabric/lakehouse/tables/list-tables?tabs=HTTP"""

    # TODO: Add support for maxResults parameter

    args.uri = f"workspaces/{args.ws_id}/lakehouses/{args.lakehouse_id}/tables"
    args.method = "get"

    response = fabric_api.do_request(args)

    return response


def load_table(args, payload):
    """https://learn.microsoft.com/en-us/rest/api/fabric/lakehouse/tables/load-table?tabs=HTTP"""

    args.uri = f"workspaces/{args.ws_id}/lakehouses/{args.lakehouse_id}/tables/{args.table_name}/load"
    args.method = "post"

    response = fabric_api.do_request(args, data=payload)

    return response
