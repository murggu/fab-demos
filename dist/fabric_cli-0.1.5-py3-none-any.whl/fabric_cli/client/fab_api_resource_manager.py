from fabric_cli.client import fab_api_client as fabric_api


def get_provider_azure(args):
    """https://learn.microsoft.com/en-us/rest/api/resources/providers/get?view=rest-resources-2021-04-01&tabs=HTTP"""

    args.audience = "azure"
    subscription_id = args.subscription_id
    provider_namespace = args.provider_namespace
    args.uri = f"subscriptions/{subscription_id}/providers/{provider_namespace}?api-version=2021-04-01"
    args.method = "get"

    return fabric_api.do_request(args)
