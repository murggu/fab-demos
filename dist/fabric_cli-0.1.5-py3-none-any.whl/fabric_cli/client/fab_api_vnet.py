from fabric_cli.client import fab_api_client as fabric_api


def list_vnets_azure(args):
    """https://learn.microsoft.com/en-us/rest/api/virtualnetwork/virtual-networks/list-all?view=rest-virtualnetwork-2024-05-01&tabs=HTTP"""

    subscription_id = args.subscription_id
    args.audience = "azure"
    args.uri = f"subscriptions/{subscription_id}/providers/Microsoft.Network/virtualNetworks?api-version=2024-05-01"
    args.method = "get"

    return fabric_api.do_request(args)
