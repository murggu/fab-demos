from fabric_cli.core.fab_commands import Command
from fabric_cli.labels import fab_labels_list_local as labels_list_local
from fabric_cli.labels import fab_labels_rm as labels_rm
from fabric_cli.labels import fab_labels_set as labels_set
from fabric_cli.utils import fab_handle_context as handle_context
from fabric_cli.utils import fab_cmd_label_utils as utils_label
from fabric_cli.utils.fab_error_parser import handle_custom_exceptions
from fabric_cli.utils.fab_util import set_command_context


@handle_custom_exceptions()
@set_command_context()
def set_command(args):
    context = handle_context.get_command_context(args.path)
    context.check_command_support(Command.LABEL_SET)
    exists = utils_label.read_labels_definition(args)
    if exists:
        labels_set.exec_command(args, context)


@handle_custom_exceptions()
@set_command_context()
def rm_command(args):
    context = handle_context.get_command_context(args.path)
    context.check_command_support(Command.LABEL_RM)
    exists = utils_label.read_labels_definition(args)
    if exists:
        labels_rm.exec_command(args, context)


@handle_custom_exceptions()
@set_command_context()
def listlocal_command(args):
    exists = utils_label.read_labels_definition(args)
    if exists:
        labels_list_local.exec_command(args)
