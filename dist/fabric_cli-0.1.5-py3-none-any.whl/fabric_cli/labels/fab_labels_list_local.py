import json

from fabric_cli.utils import fab_ui as utils_ui
from fabric_cli.utils.fab_custom_exception import CustomError


def exec_command(args):

    try:
        with open(args.input, "r") as file:
            data = json.load(file)
            columns = ["name", "id"]
            utils_ui.print_entries_unix_style(data["labels"], columns, header=True)
    except Exception as e:
        raise CustomError("Invalid_path: No such file or directory")
