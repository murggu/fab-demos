import json

from fabric_cli.client import fab_api_labels as api_labels
from fabric_cli.core import fab_constant
from fabric_cli.core.fab_hiearchy import Item
from fabric_cli.utils import fab_cmd_label_utils as utils_label
from fabric_cli.utils import fab_ui as utils_ui
from fabric_cli.utils.fab_custom_exception import CustomError


def exec_command(args, context):
    if isinstance(context, Item):
        _set_label_item(context, args)


# Items
def _set_label_item(item: Item, args):

    if args.force or utils_ui.prompt_confirm():

        item_id = item.get_id()
        item_type = item.get_item_type().value
        label_id = utils_label.get_label_id_by_name(args)

        if label_id is None:
            raise CustomError(
                f"Id not found for label '{args.name}'",
                fab_constant.ERROR_INVALID_INPUT,
            )

        payload = json.dumps(
            {
                "items": [{"id": item_id, "type": item_type}],
                "labelId": label_id,
                "assignmentMethod": "Standard",
            }
        )

        utils_ui.print_grey(f"Setting '{args.name}' label...")
        response = api_labels.set_sensi_labels(args, payload)

        if response.status_code == 403:
            raise CustomError(f"Not sufficient permissions to perform this operation")
        elif response.status_code == 200:
            utils_ui.print_done("Label set")
