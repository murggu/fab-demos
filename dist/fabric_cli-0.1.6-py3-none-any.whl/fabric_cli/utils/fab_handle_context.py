import re
from collections import deque

from fabric_cli.core import fab_commands as cmd
from fabric_cli.core import fab_constant, fab_logger
from fabric_cli.core.fab_commands import Command
from fabric_cli.core.fab_context import Context
from fabric_cli.core.fab_hiearchy import (
    FabricElement,
    Item,
    OneLakeItem,
    Tenant,
    VirtualItem,
    VirtualItemContainer,
    VirtualWorkspace,
    VirtualWorkspaceItem,
    Workspace,
)
from fabric_cli.core.fab_types import (
    FabricElementType,
    LakehouseFolders,
    OneLakeItemType,
    VirtualItemContainerType,
    VirtualItemType,
    VirtualWorkspaceItemType,
    VirtualWorkspaceType,
    WorkspaceType,
)
from fabric_cli.utils import fab_mem_store as mem_store
from fabric_cli.core.fab_auth import FabAuth
from fabric_cli.utils.fab_custom_exception import CustomError


def get_command_context(local_path, raise_error=True):
    """Get the context of the command based on the path and the context.
    Args:
        local_path (str): The path provided in the command.
    Returns:
        dict: The context of the command.
    """
    # Check if the path is an array, and if true join it using whitespace
    if isinstance(local_path, list):
        local_path = " ".join(local_path).strip("\"'")

    if local_path.startswith("/"):
        # Handle absolute path
        path = local_path
    elif local_path == "~" or local_path.startswith("~/"):
        # Handle relative path (from home directory)
        path = local_path.replace("~", f"/{get_personal_workspace_name()}", 1)
    else:
        # Handle relative path (from current context)
        path = f"{Context().get_context().get_path().rstrip('/')}/{local_path}"

    # Strip the / at the end of the path
    if len(path) > 1:
        path = path.rstrip("/")

        # Remove from multiline support => Needed for scape characters
        # path = path.replace("\\", "").strip()

    # Special cases for root and parent are handled here to avoid unnecessary API calls
    if path == "/" or path == "/..":
        local_context = Context().get_tenant()
    else:
        local_context = process_absolute_path(path, raise_error)

    if local_context.get_type() in [FabricElementType.VIRTUAL_ITEM_CONTAINER, FabricElementType.VIRTUAL_ITEM]:
        if local_context.get_item_type() == VirtualItemType.EXTERNAL_DATA_SHARE:
            fab_logger.log_warning(
                    "Ensure tenant setting is enabled for External data sharing"
                )

    return local_context


def process_path_part(
    path_parts: deque[str], context: deque[FabricElement], raise_error: bool = True
) -> FabricElement:
    """Process the path parts and determine the context"""

    if not path_parts:
        return context.pop()

    path_part = path_parts.popleft()
    cur_ctxt = context[-1]

    match path_part:
        case "..":
            # Return to parent context (tenant is the root context)
            if cur_ctxt.get_type != FabricElementType.TENANT:
                context.pop()
            return process_path_part(path_parts, context, raise_error)
        case "." | "":
            # Return to the same context
            return process_path_part(path_parts, context, raise_error)
        case x if re.match("\\.\\.\\.+", x):
            # Invalid path
            raise CustomError("Invalid path", fab_constant.ERROR_INVALID_PATH)
        case _:
            # Process the part of the path depending on the context
            return process_context_path(
                path_part, path_parts, context, cur_ctxt, raise_error
            )


def process_context_path(
    path_part,
    path_parts: deque[str],
    context: deque[FabricElement],
    cur_ctxt,
    raise_error: bool = True,
) -> FabricElement:
    match cur_ctxt.get_type():
        case FabricElementType.TENANT:
            return _handle_path_in_tenant(
                path_part, path_parts, cur_ctxt, context, raise_error
            )
        case FabricElementType.WORKSPACE:
            return _handle_path_in_ws(
                path_part, path_parts, cur_ctxt, context, raise_error
            )
        case FabricElementType.VIRTUAL_WORKSPACE:
            return _handle_path_in_vws(
                path_part, path_parts, cur_ctxt, context, raise_error
            )
        case FabricElementType.ITEM:
            return _handle_path_in_item(
                path_part, path_parts, cur_ctxt, context, raise_error
            )
        case FabricElementType.VIRTUAL_ITEM_CONTAINER:
            return _handle_path_in_vic(
                path_part, path_parts, cur_ctxt, context, raise_error
            )
        # FabricElementType.VIRTUAL_ITEM | FabricElementType.VIRTUAL_WORKSPACE_ITEM:
        case _:
            raise CustomError(
                f"Traversing into {cur_ctxt.get_path()} is not supported",
                fab_constant.ERROR_INVALID_PATH,
            )


def process_absolute_path(path: str, raise_error=True) -> FabricElement:
    """Process absolute path and return the corresponding context."""
    # Split the path into parts. The path separator is "/", but should be ignored if it is part of the name of the element, in which case it should be escaped with "\".
    path_parts = deque(x.replace("\\", "").strip() for x in re.split(r"(?<!\\)/", path))
    context_stack: deque[FabricElement] = deque(maxlen=len(path_parts))
    context_stack.append(Context().get_tenant())

    local_context = process_path_part(path_parts, context_stack, raise_error)

    return local_context


def get_personal_workspace_name():
    """Get the personal workspace name."""
    # Personal workspace name is only available in interactive mode
    if FabAuth().get_auth_mode() == "user":
        # Personal workspace is the only workspace that is not in the format <name>.Workspace but <name>.Personal
        _workspaces = mem_store.get_workspaces(Context().get_tenant().get_id())
        for ws in _workspaces:
            if ws.get_ws_type() == WorkspaceType.PERSONAL:
                return ws.get_name()
        raise CustomError(
            "Personal workspace not found",
            fab_constant.ERROR_NOT_FOUND,
        )
    else:
        raise CustomError(
            "Personal workspace is only available in user authentication mode",
            fab_constant.ERROR_INVALID_OPERATION,
        )


def _get_workspace_id(tenant: Tenant, ws_name: str, raise_error: bool = True):
    try:
        workspace_id = mem_store.get_workspace_id(tenant, ws_name)
    except CustomError as e:
        if not (raise_error) and e.status_code == fab_constant.ERROR_NOT_FOUND:
            workspace_id = None
        else:
            raise e

    return workspace_id


def _get_capacity_id(tenant: Tenant, capacity_name: str, raise_error: bool = True):
    try:
        capacity_id = mem_store.get_capacity_id(tenant, capacity_name)
    except CustomError as e:
        if not (raise_error) and e.status_code == fab_constant.ERROR_NOT_FOUND:
            capacity_id = None
        else:
            raise e

    return capacity_id


def _get_domain_id(tenant: Tenant, domain_name: str, raise_error: bool = True):
    try:
        domain_id = mem_store.get_domain_id(tenant, domain_name)
    except CustomError as e:
        if not (raise_error) and e.status_code == fab_constant.ERROR_NOT_FOUND:
            domain_id = None
        else:
            raise e

    return domain_id


def _get_connection_id(tenant: Tenant, connection_name: str, raise_error: bool = True):
    try:
        connection_id = mem_store.get_connection_id(tenant, connection_name)
    except CustomError as e:
        if not (raise_error) and e.status_code == fab_constant.ERROR_NOT_FOUND:
            connection_id = None
        else:
            raise e

    return connection_id


def _get_gateway_id(tenant: Tenant, gateway_name: str, raise_error: bool = True):
    try:
        gateway_id = mem_store.get_gateway_id(tenant, gateway_name)
    except CustomError as e:
        if not (raise_error) and e.status_code == fab_constant.ERROR_NOT_FOUND:
            gateway_id = None
        else:
            raise e

    return gateway_id


def _get_item_id(workspace: Workspace, item_name: str, raise_error: bool = True):
    try:
        item_id = mem_store.get_item_id(workspace, item_name)
    except CustomError as e:
        if not (raise_error) and e.status_code == fab_constant.ERROR_NOT_FOUND:
            item_id = None
        else:
            raise e

    return item_id


def _get_spark_pool_id(
    container: VirtualItemContainer, spark_pool_name: str, raise_error: bool = True
):
    try:
        spark_pool_id = mem_store.get_spark_pool_id(container, spark_pool_name)
    except CustomError as e:
        if not (raise_error) and e.status_code == fab_constant.ERROR_NOT_FOUND:
            spark_pool_id = None
        else:
            raise e

    return spark_pool_id


def _get_managed_identity_id(
    container: VirtualItemContainer,
    managed_identity_name: str,
    raise_error: bool = True,
):
    try:
        managed_identity_id = mem_store.get_managed_identity_id(
            container, managed_identity_name
        )
    except CustomError as e:
        if not (raise_error) and e.status_code == fab_constant.ERROR_NOT_FOUND:
            managed_identity_id = None
        else:
            raise e

    return managed_identity_id


def _get_managed_private_endpoint_id(
    container: VirtualItemContainer,
    managed_private_endpoint_name: str,
    raise_error: bool = True,
):
    try:
        managed_private_endpoint_id = mem_store.get_managed_private_endpoint_id(
            container, managed_private_endpoint_name
        )
    except CustomError as e:
        if not (raise_error) and e.status_code == fab_constant.ERROR_NOT_FOUND:
            managed_private_endpoint_id = None
        else:
            raise e

    return managed_private_endpoint_id


def _get_external_data_share_id(
    container: VirtualItemContainer,
    external_data_share_name: str,
    raise_error: bool = True,
):
    try:
        external_data_share_id = mem_store.get_external_data_share_id(
            container, external_data_share_name
        )
    except CustomError as e:
        if not (raise_error) and e.status_code == fab_constant.ERROR_NOT_FOUND:
            external_data_share_id = None
        else:
            raise e

    return external_data_share_id


def _handle_path_in_tenant(
    path_part: str,
    path_parts,
    tenant: Tenant,
    context: deque[FabricElement],
    raise_error,
):
    elem_type_str = path_part
    # There are two types of path parts: Name.ElementType and .VirtualWorkspaceType
    if not path_part.startswith("."):
        elem_type_str = path_part.split(".")[-1]
    try:
        elem = FabricElementType.from_string(elem_type_str)
    except CustomError:
        elem = None
    match elem:
        case FabricElementType.WORKSPACE:
            (ws_name, ws_type) = Workspace.validate_name(path_part)
            full_ws_name = f"{ws_name}.{ws_type.value}"
            ws_id = _get_workspace_id(tenant, full_ws_name, raise_error)
            workspace = Workspace(ws_name, ws_id, tenant, ws_type.value)
            context.append(workspace)
            return process_path_part(path_parts, context, raise_error)
        case FabricElementType.VIRTUAL_WORKSPACE:
            (vws_name, type) = VirtualWorkspace.validate_name(path_part)
            if type not in [
                VirtualWorkspaceType.CAPACITY,
                VirtualWorkspaceType.CONNECTION,
                VirtualWorkspaceType.GATEWAY,
                VirtualWorkspaceType.DOMAIN,
            ]:
                raise CustomError(
                    f"type {type} not supported",
                    fab_constant.ERROR_INVALID_OPERATION,
                )
            vws = VirtualWorkspace(vws_name, None, tenant)
            context.append(vws)
            return process_path_part(path_parts, context, raise_error)

        case _:
            _path = f"/{path_part}"
            raise CustomError(
                f"Invalid path '{_path}'", fab_constant.ERROR_INVALID_PATH
            )


def _handle_path_in_ws(
    path_part,
    path_parts,
    workspace: Workspace,
    context: deque[FabricElement],
    raise_error,
):
    ws_id = workspace.get_id()
    if ws_id is None:
        raise CustomError(
            f"Workspace not found '{workspace.get_name()}'",
            fab_constant.ERROR_NOT_FOUND,
        )
    elem_type_str = path_part
    # There are two types of path parts: Name.ElementType and .VirtualWorkspaceType
    if not path_part.startswith("."):
        elem_type_str = path_part.split(".")[-1]
    try:
        elem = FabricElementType.from_string(elem_type_str)
    except CustomError:
        elem = None
    match elem:
        case FabricElementType.ITEM:
            (item_name, item_type) = Item.validate_name(path_part)
            item_full_name = f"{item_name}.{item_type.value}"
            _item_id = _get_item_id(workspace, item_full_name, raise_error)
            item = Item(item_name, _item_id, workspace, str(item_type))
            context.append(item)
            return process_path_part(path_parts, context, raise_error)
        case FabricElementType.VIRTUAL_ITEM_CONTAINER:
            (vic_name, vic_type) = VirtualItemContainer.validate_name(path_part)
            if vic_type not in [
                VirtualItemContainerType.SPARK_POOL,
                VirtualItemContainerType.MANAGED_IDENTITY,
                VirtualItemContainerType.MANAGED_PRIVATE_ENDPOINT,
                VirtualItemContainerType.EXTERNAL_DATA_SHARE,
            ]:
                raise CustomError(
                    f"type {vic_type} not supported",
                    fab_constant.ERROR_INVALID_OPERATION,
                )
            vic = VirtualItemContainer(vic_name, None, workspace)
            context.append(vic)

            return process_path_part(path_parts, context, raise_error)
        case _:
            _path = f"{workspace.get_path()}/{path_part}"
            raise CustomError(f"Invalid path: {_path}", fab_constant.ERROR_INVALID_PATH)


def _handle_path_in_item(
    path_part, path_parts, item: Item, context: deque[FabricElement], raise_error
):
    # Only support traversing into onelake items.
    # Onelake items are items which support the FS_LS command
    _item_type = item.get_item_type()
    _supp_items = cmd.get_supported_items(Command.FS_LS)
    _unsupp_items = cmd.get_unsupported_items(Command.FS_LS)

    # TODO: Change for item.check_command_support(Command.FS_LS)
    if _item_type in _supp_items and _item_type not in _unsupp_items:
        item_id = item.get_id()
        if item_id is None:
            raise CustomError(
                f"Item not found '{item.get_name()}'",
                fab_constant.ERROR_NOT_FOUND,
            )
        one_lake_path = (
            f"{path_part}/" + "/".join(path_parts) if path_parts else f"{path_part}"
        )
        match path_part.capitalize():
            case _ if one_lake_path.lower().endswith(
                f".{OneLakeItemType.SHORTCUT.name}".lower()
            ):
                item_type = OneLakeItemType.SHORTCUT
            case LakehouseFolders.FILES.value:
                item_type = OneLakeItemType.FILE
            case LakehouseFolders.TABLES.value:
                item_type = OneLakeItemType.TABLE
            case _:
                item_type = OneLakeItemType.OTHER
        one_lake = OneLakeItem(item, item_type, one_lake_path)
        return one_lake
    else:
        raise CustomError(
            f"Invalid path. {item.get_item_type()} does not support traversing",
            fab_constant.ERROR_INVALID_PATH,
        )


def _handle_path_in_vws(
    path_part,
    path_parts,
    cur_ctxt: VirtualWorkspace,
    context: deque[FabricElement],
    raise_error,
):
    (item_name, item_type) = VirtualWorkspaceItem.validate_name(path_part)

    if cur_ctxt.get_item_type() != item_type:
        raise CustomError(
            f"Item {item_type} not supported in {cur_ctxt.get_type()}",
            fab_constant.ERROR_INVALID_PATH,
        )

    match item_type:
        case VirtualWorkspaceItemType.CAPACITY:
            _capacity_id = _get_capacity_id(
                cur_ctxt.get_tenant(), f"{item_name}.{str(item_type)}", raise_error
            )
            capacity = VirtualWorkspaceItem(
                item_name, _capacity_id, cur_ctxt, str(item_type)
            )
            context.append(capacity)
            return process_path_part(path_parts, context, raise_error)
        case VirtualWorkspaceItemType.DOMAIN:
            _domain_id = _get_domain_id(
                cur_ctxt.get_tenant(), f"{item_name}.{str(item_type)}", raise_error
            )
            domain = VirtualWorkspaceItem(
                item_name, _domain_id, cur_ctxt, str(item_type)
            )
            context.append(domain)
            return process_path_part(path_parts, context, raise_error)
        case VirtualWorkspaceItemType.CONNECTION:
            _connection_id = _get_connection_id(
                cur_ctxt.get_tenant(), f"{item_name}.{str(item_type)}", raise_error
            )
            connection = VirtualWorkspaceItem(
                item_name, _connection_id, cur_ctxt, str(item_type)
            )
            context.append(connection)
            return process_path_part(path_parts, context, raise_error)
        case VirtualWorkspaceItemType.GATEWAY:
            _gateway_id = _get_gateway_id(
                cur_ctxt.get_tenant(), f"{item_name}.{str(item_type)}", raise_error
            )
            gateway = VirtualWorkspaceItem(
                item_name, _gateway_id, cur_ctxt, str(item_type)
            )
            context.append(gateway)
            return process_path_part(path_parts, context, raise_error)
        case _:
            raise CustomError(
                f"Item {item_type} not supported yet",
                fab_constant.ERROR_INVALID_PATH,
            )


def _handle_path_in_vic(
    path_part,
    path_parts,
    cur_ctxt: VirtualItemContainer,
    context: deque[FabricElement],
    raise_error,
):
    (item_name, item_type) = VirtualItem.validate_name(path_part)

    if cur_ctxt.get_item_type() != item_type:
        raise CustomError(
            f"Item {item_type} not supported in {cur_ctxt.get_type()}",
            fab_constant.ERROR_INVALID_PATH,
        )

    match item_type:
        case VirtualItemType.SPARK_POOL:
            _spark_pool_id = _get_spark_pool_id(
                cur_ctxt, f"{item_name}.{str(item_type)}", raise_error
            )
            spark_pool = VirtualItem(
                item_name, _spark_pool_id, cur_ctxt, str(item_type)
            )
            context.append(spark_pool)
            return process_path_part(path_parts, context, raise_error)

        case VirtualItemType.MANAGED_IDENTITY:
            _managed_identity_id = _get_managed_identity_id(
                cur_ctxt, f"{item_name}.{str(item_type)}", raise_error
            )
            managed_identity = VirtualItem(
                item_name, _managed_identity_id, cur_ctxt, str(item_type)
            )
            context.append(managed_identity)
            return process_path_part(path_parts, context, raise_error)

        case VirtualItemType.MANAGED_PRIVATE_ENDPOINT:
            _managed_private_endpoint_id = _get_managed_private_endpoint_id(
                cur_ctxt, f"{item_name}.{str(item_type)}", raise_error
            )
            managed_private_endpoint = VirtualItem(
                item_name, _managed_private_endpoint_id, cur_ctxt, str(item_type)
            )
            context.append(managed_private_endpoint)
            return process_path_part(path_parts, context, raise_error)

        case VirtualItemType.EXTERNAL_DATA_SHARE:
            _external_data_share_id = _get_external_data_share_id(
                cur_ctxt, f"{item_name}.{str(item_type)}", raise_error
            )
            external_data_share = VirtualItem(
                item_name, _external_data_share_id, cur_ctxt, str(item_type)
            )
            context.append(external_data_share)
            return process_path_part(path_parts, context, raise_error)
