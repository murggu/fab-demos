from fabric_cli.client import fab_api_client as fabric_api
from fabric_cli.client import fab_api_utils as api_utils


def delete_dir(args, bypass_confirmation, debug=True):
    """https://learn.microsoft.com/en-us/rest/api/storageservices/datalakestoragegen2/path/delete?view=rest-storageservices-datalakestoragegen2-2019-12-12"""

    args.uri = f"{args.directory}/?recursive=true"
    args.method = "delete"
    args.audience = "storage"

    api_utils.delete_resource(args, bypass_confirmation, debug)


def list_tables_files(args):
    # args.uri = f"{args.ws_name}/{args.item}/?recursive=false&resource=filesystem"
    args.uri = f"{args.directory}/?recursive=false&resource=filesystem"
    args.method = "get"
    args.audience = "storage"

    response = fabric_api.do_request(args)

    return response


def list_tables_files_recursive(args):
    # args.uri = (
    #     f"{args.directory}/?recursive=true&resource=filesystem&getShortcutMetadata=true"
    # )
    args.uri = args.directory
    args.method = "get"
    args.audience = "storage"

    response = fabric_api.do_request(args)

    return response


def create_dir(args):
    """https://learn.microsoft.com/en-us/rest/api/storageservices/datalakestoragegen2/path/create?view=rest-storageservices-datalakestoragegen2-2019-12-12"""

    args.uri = f"{args.directory}/?resource=directory"
    args.method = "put"
    args.audience = "storage"

    headers = {"If-None-Match": "*"}
    args.headers = headers

    response = fabric_api.do_request(args)

    return response


def move_rename(args):
    """https://learn.microsoft.com/en-us/rest/api/storageservices/datalakestoragegen2/path/create?view=rest-storageservices-datalakestoragegen2-2019-12-12"""

    args.headers = {"x-ms-rename-source": args.from_path}
    args.uri = f"{args.to_path}"
    args.method = "put"
    args.audience = "storage"

    response = fabric_api.do_request(args)

    return response


def get(args):
    """https://learn.microsoft.com/en-us/rest/api/storageservices/datalakestoragegen2/path?view=rest-storageservices-datalakestoragegen2-2019-12-12"""

    args.uri = f"{args.from_path}"
    args.method = "get"
    args.audience = "storage"

    response = fabric_api.do_request(args)

    return response


def get_properties(args):
    """https://learn.microsoft.com/en-us/rest/api/storageservices/datalakestoragegen2/path?view=rest-storageservices-datalakestoragegen2-2019-12-12"""

    args.uri = f"{args.from_path}"
    args.method = "head"
    args.audience = "storage"

    response = fabric_api.do_request(args)

    return response


def read(args):
    """https://learn.microsoft.com/en-us/rest/api/storageservices/datalakestoragegen2/path?view=rest-storageservices-datalakestoragegen2-2019-12-12"""

    args.uri = f"{args.from_path}"
    args.method = "get"
    args.audience = "storage"

    response = fabric_api.do_request(args)

    return response


def touch_file(args):
    args.uri = f"{args.to_path}/?resource=file"
    args.method = "put"
    args.audience = "storage"

    response = fabric_api.do_request(args)

    return response


def append_file(args, content, position, content_type="application/json"):
    args.uri = f"{args.to_path}?action=append&position={position}"
    args.method = "patch"
    args.audience = "storage"
    args.headers = {"Content-Length": str(len(content)), "Content-Type": content_type}

    response = fabric_api.do_request(args, data=content)

    return response.status_code


def flush_file(args, position):
    args.uri = f"{args.to_path}?action=flush&position={position}"
    args.method = "patch"
    args.audience = "storage"
    args.headers = {"Content-Length": "0"}

    response = fabric_api.do_request(args)

    return response.status_code


# ACLs
def acl_list_data_access_roles(args):
    """https://learn.microsoft.com/en-us/rest/api/fabric/core/onelake-data-access-security/list-data-access-roles?tabs=HTTP"""

    args.uri = f"workspaces/{args.ws_id}/items/{args.id}/dataAccessRoles"
    args.method = "get"

    response = fabric_api.do_request(args)

    return response


def acl_add_data_access_role(args, payload):
    """https://learn.microsoft.com/en-us/rest/api/fabric/core/onelake-data-access-security/create-or-update-data-access-roles?tabs=HTTP"""

    args.uri = f"workspaces/{args.ws_id}/items/{args.id}/dataAccessRoles"
    args.method = "put"

    response = fabric_api.do_request(args, data=payload)

    return response
