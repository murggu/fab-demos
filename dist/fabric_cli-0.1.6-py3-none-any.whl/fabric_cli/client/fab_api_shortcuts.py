from fabric_cli.client import fab_api_client as fabric_api
from fabric_cli.client import fab_api_utils as api_utils


def create_shortcut(args, payload):
    """https://learn.microsoft.com/en-us/rest/api/fabric/core/onelake-shortcuts/create-shortcut?tabs=HTTP"""

    args.uri = f"workspaces/{args.ws_id}/items/{args.id}/shortcuts?shortcutConflictPolicy={args.shortcutConflictPolicy}"
    args.method = "post"

    return fabric_api.do_request(args, json=payload)


def get_shortcut(args):
    """https://learn.microsoft.com/en-us/rest/api/fabric/core/onelake-shortcuts/get-shortcut?tabs=HTTP"""

    args.uri = (
        f"workspaces/{args.ws_id}/items/{args.id}/shortcuts/{args.path}/{args.name}"
    )
    args.method = "get"

    return fabric_api.do_request(args)


def delete_shortcut(args, bypass_confirmation, debug=True):
    """https://learn.microsoft.com/en-us/rest/api/fabric/core/onelake-shortcuts/delete-shortcut?tabs=HTTP"""

    args.uri = (
        f"workspaces/{args.ws_id}/items/{args.id}/shortcuts/{args.path}/{args.sc_name}"
    )
    args.method = "delete"

    return api_utils.delete_resource(args, bypass_confirmation, debug)
