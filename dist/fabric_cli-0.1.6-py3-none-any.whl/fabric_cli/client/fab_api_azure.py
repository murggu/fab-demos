from fabric_cli.client import fab_api_client as fabric_api


def get_provider_azure(args):
    """https://learn.microsoft.com/en-us/rest/api/resources/providers/get?view=rest-resources-2021-04-01&tabs=HTTP"""

    args.audience = "azure"
    subscription_id = args.subscription_id
    provider_namespace = args.provider_namespace
    args.uri = f"subscriptions/{subscription_id}/providers/{provider_namespace}?api-version=2021-04-01"
    args.method = "get"

    return fabric_api.do_request(args)


def list_subscriptions_azure(args):
    """https://learn.microsoft.com/en-us/rest/api/resources/subscriptions/list?view=rest-resources-2022-12-01&tabs=HTTP"""

    args.audience = "azure"
    args.uri = "subscriptions?api-version=2022-12-01"
    args.method = "get"

    return fabric_api.do_request(args)


def list_vnets_azure(args):
    """https://learn.microsoft.com/en-us/rest/api/virtualnetwork/virtual-networks/list-all?view=rest-virtualnetwork-2024-05-01&tabs=HTTP"""

    subscription_id = args.subscription_id
    args.audience = "azure"
    args.uri = f"subscriptions/{subscription_id}/providers/Microsoft.Network/virtualNetworks?api-version=2024-05-01"
    args.method = "get"

    return fabric_api.do_request(args)
