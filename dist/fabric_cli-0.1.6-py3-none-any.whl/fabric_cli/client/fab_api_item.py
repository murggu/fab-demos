import json

from fabric_cli.client import fab_api_client as fabric_api
from fabric_cli.client import fab_api_utils as api_utils


def create_item(args, payload=None, item_uri=False):
    """https://learn.microsoft.com/en-us/rest/api/fabric/core/items/create-item?tabs=HTTP"""

    if item_uri:
        args.uri = f"workspaces/{args.ws_id}/{args.item_uri}"
    else:
        args.uri = f"workspaces/{args.ws_id}/items"

    args.method = "post"
    args.wait = True  # Wait for the item to be created in order to get the details

    if payload is not None:
        response = fabric_api.do_request(args, data=payload)
    else:
        response = fabric_api.do_request(args)

    return response


def delete_item(
    args,
    bypass_confirmation=False,
    item_uri=False,
    debug=True,
    override_method=None,
    operation=None,
):
    """https://learn.microsoft.com/en-us/rest/api/fabric/core/items/delete-item?tabs=HTTP"""

    if not hasattr(args, "uri") or not args.uri:
        if item_uri:
            args.uri = f"workspaces/{args.ws_id}/{args.item_uri}/{args.id}"
        else:
            args.uri = f"workspaces/{args.ws_id}/items/{args.id}"

    args.method = override_method if override_method else "delete"

    if operation is not None:
        return api_utils.delete_resource(args, bypass_confirmation, debug, operation)
    return api_utils.delete_resource(args, bypass_confirmation, debug)


def get_item_withdefinition(args, item_uri=False):
    """https://learn.microsoft.com/en-us/rest/api/fabric/core/items/get-item-definition?tabs=HTTP"""

    response = get_item(args, item_uri)
    item = json.loads(response.text)

    args.uri = f"workspaces/{args.ws_id}/items/{args.id}/getDefinition{args.format}"
    args.method = "post"
    args.wait = True  # Wait for the details to be retrieved

    def_response = fabric_api.do_request(args)

    if def_response.status_code == 200:
        definition = json.loads(def_response.text)
        if isinstance(definition, dict):
            item.update(definition)

            return item


def get_item(args, item_uri=False, ext_uri=False):
    """https://learn.microsoft.com/en-us/rest/api/fabric/core/items/get-item?tabs=HTTP"""

    if item_uri:
        args.uri = f"workspaces/{args.ws_id}/{args.item_uri}/{args.id}"
    else:
        args.uri = f"workspaces/{args.ws_id}/items/{args.id}"

    if ext_uri:
        args.uri = args.uri + args.ext_uri

    args.method = "get"

    response = fabric_api.do_request(args)

    if response.status_code == 200:
        return response


def update_item_definition(args, payload):
    """https://learn.microsoft.com/en-us/rest/api/fabric/core/items/update-item-definition"""

    args.uri = f"workspaces/{args.ws_id}/items/{args.id}/updateDefinition"
    args.method = "post"

    response = fabric_api.do_request(args, data=payload)

    if response.status_code == 200:
        return response


def update_item(args, payload, item_uri=False):
    """https://learn.microsoft.com/en-us/rest/api/fabric/core/items/update-item"""

    if item_uri:
        args.uri = f"workspaces/{args.ws_id}/{args.item_uri}/{args.id}"
    else:
        args.uri = f"workspaces/{args.ws_id}/items/{args.id}"

    args.method = "patch"

    response = fabric_api.do_request(args, data=payload)

    if response.status_code == 200:
        return response


# ACLs


# [admin]
def acl_list_from_item(args):
    """https://learn.microsoft.com/en-us/rest/api/fabric/admin/items/list-item-access-details?tabs=HTTP"""

    args.uri = f"admin/workspaces/{args.ws_id}/items/{args.id}/users"
    args.method = "get"

    response = fabric_api.do_request(args)

    return response


# Connections


def get_item_connections(args):
    """https://learn.microsoft.com/en-us/rest/api/fabric/core/items/list-item-connections?tabs=HTTP"""

    args.uri = f"workspaces/{args.ws_id}/items/{args.id}/connections"
    args.method = "get"

    response = fabric_api.do_request(args)

    if response.status_code == 200:
        return response


# External Data Shares


def create_item_external_data_share(args, payload=None):
    """https://learn.microsoft.com/en-us/rest/api/fabric/core/external-data-shares/create-external-data-share?tabs=HTTP"""

    args.uri = f"workspaces/{args.ws_id}/items/{args.item_id}/externalDataShares"

    args.method = "post"
    args.wait = True  # Wait for the item to be created in order to get the details

    return fabric_api.do_request(args, data=payload)


def get_item_external_data_share(args):
    """https://learn.microsoft.com/en-us/rest/api/fabric/core/external-data-shares/get-external-data-share?tabs=HTTP"""

    args.uri = (
        f"workspaces/{args.ws_id}/items/{args.item_id}/externalDataShares/{args.id}"
    )

    args.method = "get"

    return fabric_api.do_request(args)


def list_item_external_data_shares(args):
    """https://learn.microsoft.com/en-us/rest/api/fabric/core/external-data-shares/list-external-data-shares-in-item?tabs=HTTP"""

    args.uri = f"workspaces/{args.ws_id}/items/{args.item_id}/externalDataShares"
    args.method = "get"

    return fabric_api.do_request(args)


def revoke_item_external_data_share(args, bypass_confirmation=False, debug=True):
    """https://learn.microsoft.com/en-us/rest/api/fabric/core/external-data-shares/revoke-external-data-share?tabs=HTTP"""

    args.uri = f"workspaces/{args.ws_id}/items/{args.item_id}/externalDataShares/{args.id}/revoke"
    # Using Overrides since Revoke API is a POST api without object id in the URI.
    override_method = "post"
    return delete_item(
        args,
        bypass_confirmation=bypass_confirmation,
        debug=debug,
        override_method=override_method,
        operation="revoke",
    )
