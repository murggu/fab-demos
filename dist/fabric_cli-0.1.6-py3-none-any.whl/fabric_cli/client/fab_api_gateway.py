from fabric_cli.client import fab_api_client as fabric_api
from fabric_cli.client import fab_api_utils as api_utils


def create_gateway(args, payload):
    """https://learn.microsoft.com/en-us/rest/api/fabric/core/gateways/create-gateway?tabs=HTTP"""

    args.uri = "gateways"
    args.method = "post"

    return fabric_api.do_request(args, data=payload)


def get_gateway(args):
    """https://learn.microsoft.com/en-us/rest/api/fabric/core/gateways/get-gateway?tabs=HTTP"""

    args.uri = f"gateways/{args.id}"
    args.method = "get"

    return fabric_api.do_request(args)


def update_gateway(args, payload):
    """https://learn.microsoft.com/en-us/rest/api/fabric/core/gateways/update-gateway?tabs=HTTP"""

    args.uri = f"gateways/{args.id}"
    args.method = "patch"

    return fabric_api.do_request(args, data=payload)


def delete_gateway(args, bypass_confirmation=False):
    """https://learn.microsoft.com/en-us/rest/api/fabric/core/gateways/delete-gateway?tabs=HTTP"""

    args.uri = f"gateways/{args.id}"
    args.method = "delete"

    return api_utils.delete_resource(args, bypass_confirmation)


def list_gateways(args):
    """https://learn.microsoft.com/en-us/rest/api/fabric/core/gateways/list-gateways?tabs=HTTP"""

    args.uri = "gateways"
    args.method = "get"

    return fabric_api.do_request(args)


# Members


def update_gateway_member(args, payload):
    """https://learn.microsoft.com/en-us/rest/api/fabric/core/gateways/update-gateway-member?tabs=HTTP"""

    args.uri = f"gateways/{args.id}/members/{args.member_id}"
    args.method = "patch"

    return fabric_api.do_request(args, data=payload)


def list_gateway_members(args):
    """https://learn.microsoft.com/en-us/rest/api/fabric/core/gateways/list-gateway-members?tabs=HTTP"""

    args.uri = f"gateways/{args.id}/members"
    args.method = "get"

    return fabric_api.do_request(args)


def delete_gateway_member(args, bypass_confirmation=False):
    """https://learn.microsoft.com/en-us/rest/api/fabric/core/gateways/delete-gateway-member?tabs=HTTP"""

    args.uri = f"gateways/{args.id}/members/{args.member_id}"
    args.method = "delete"

    return api_utils.delete_resource(args, bypass_confirmation)


# ACLs


def acl_list_from_gateway(args):
    """https://learn.microsoft.com/en-us/rest/api/fabric/core/gateways/list-gateway-role-assignments?tabs=HTTP"""

    args.uri = f"gateways/{args.gw_id}/roleAssignments"
    args.method = "get"

    return fabric_api.do_request(args)


def acl_delete_from_gateway(args):
    """https://learn.microsoft.com/en-us/rest/api/fabric/core/gateways/delete-gateway-role-assignment?tabs=HTTP"""

    args.uri = f"gateways/{args.gw_id}/roleAssignments/{args.id}"
    args.method = "delete"

    return fabric_api.do_request(args)


def acl_add_for_gateway(args, payload):
    """https://learn.microsoft.com/en-us/rest/api/fabric/core/gateways/add-gateway-role-assignment?tabs=HTTP"""

    args.uri = f"gateways/{args.gw_id}/roleAssignments"
    args.method = "post"

    return fabric_api.do_request(args, data=payload)


def acl_update_for_gateway(args, payload):
    """https://learn.microsoft.com/en-us/rest/api/fabric/core/gateways/update-gateway-role-assignment?tabs=HTTP"""

    args.uri = f"gateways/{args.gw_id}/roleAssignments/{args.id}"
    args.method = "patch"

    return fabric_api.do_request(args, data=payload)


def acl_get_for_gateway(args):
    """https://learn.microsoft.com/en-us/rest/api/fabric/core/gateways/get-gateway-role-assignment?tabs=HTTP"""

    args.uri = f"gateways/{args.gw_id}/roleAssignments/{args.id}"
    args.method = "get"

    return fabric_api.do_request(args)
