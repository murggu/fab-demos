import json

from fabric_cli.client import fab_api_capacity as capacity_api
from fabric_cli.client import fab_api_connection as connection_api
from fabric_cli.client import fab_api_domain as domain_api
from fabric_cli.client import fab_api_gateway as gateways_api
from fabric_cli.client import fab_api_item as item_api
from fabric_cli.client import fab_api_shortcuts as shortcut_api
from fabric_cli.client import fab_api_sparkpool as sparkpool_api
from fabric_cli.client import fab_api_workspace as workspace_api
from fabric_cli.core import fab_constant, fab_logger
from fabric_cli.core.fab_commands import Command
from fabric_cli.core.fab_context import Context
from fabric_cli.core.fab_hiearchy import (
    FabricElement,
    Item,
    OneLakeItem,
    VirtualItem,
    VirtualWorkspaceItem,
    Workspace,
)
from fabric_cli.core.fab_types import (
    OneLakeItemType,
    VirtualItemType,
    VirtualWorkspaceItemType,
)
from fabric_cli.fs import fab_fs as fs
from fabric_cli.fs import fab_fs_get as fs_get
from fabric_cli.fs import fab_fs_rm as fs_rm
from fabric_cli.fs import fab_fs_cd as fs_cd
from fabric_cli.utils import fab_mem_store as utils_mem_store
from fabric_cli.utils import fab_ui as utils_ui
from fabric_cli.utils import fab_util as utils
from fabric_cli.utils import fab_cmd_set_utils as utils_set
from fabric_cli.utils.fab_custom_exception import CustomError

JMESPATH_UPDATE_WORKSPACE = [
    "description",
    "displayName",
    "sparkSettings",
]
JMESPATH_UPDATE_SHORTCUT = ["name", "target"]
JMESPATH_UPDATE_SPARKPOOL = [
    "name",
    "nodeSize",
    "autoScale.enabled",
    "autoScale.minNodeCount",
    "autoScale.maxNodeCount",
]
JMESPATH_UPDATE_CAPACITIES = ["sku.name"]
JMESPATH_UPDATE_DOMAINS = ["contributorsScope", "description", "displayName"]
JMESPATH_UPDATE_CONNECTIONS = ["displayName", "privacyLevel", "credentialDetails"]

JMESPATH_UPDATE_GATEWAYS = [
    "displayName",
    "allowCloudConnectionRefresh",
    "allowCustomConnectors",
    "capacityId",
    "inactivityMinutesBeforeSleep",
    "numberOfMemberGateways",
]


def exec_command(args, context: FabricElement):

    args.query = utils.process_nargs(args.query)
    args.input = utils.process_nargs(args.input)

    # Check if the context has changed
    # This can be either the current context or a parent context
    _changed_context = context.get_path() in Context().get_context().get_path()
    _old_path = context.get_path()

    if isinstance(context, Workspace):
        _set_workspace(context, args)
    elif isinstance(context, Item):
        _set_item(context, args)
    elif isinstance(context, VirtualItem):
        _set_virtual_item(context, args)
    elif isinstance(context, VirtualWorkspaceItem):
        _set_virtual_ws_item(context, args)
    elif isinstance(context, OneLakeItem):
        if context.get_nested_type() == OneLakeItemType.SHORTCUT:
            _set_shortcut(context, args)
        else:
            raise CustomError("Not supported", fab_constant.ERROR_NOT_SUPPORTED)
    
    # If the context has changed, execute the cd command
    if _changed_context and (context.get_path() != _old_path):
        fs_cd.exec_command(args, context)


# Workspaces
def _set_workspace(workspace: Workspace, args):

    query = args.query

    utils_set.validate_expression(query, JMESPATH_UPDATE_WORKSPACE)

    # Get workspace
    args.verbose = True
    args.output = None
    workspace_def = fs_get._get_workspace(workspace, args, debug=False)

    fab_logger.log_warning("Modifying properties may lead to unintended consequences")

    if args.force or utils_ui.prompt_confirm():

        json_payload, updated_def = utils_set.update_fabric_element(
            workspace_def, query, args.input, decode_encode=False
        )

        # Separate definition + displayName and description item properties
        definition_base64_to_update, name_description_properties = (
            utils_set.extract_json_schema(updated_def, definition=False)
        )

        args.ws_id = workspace.get_id()
        update_workspace_payload = json.dumps(name_description_properties)

        utils_ui.print_grey(f"Setting new property for '{workspace.get_name()}'...")

        # Update workspace settings
        if query.startswith("sparkSettings"):
            spark_settings_def = updated_def["sparkSettings"]
            updated_spark_settings_def = json.dumps(spark_settings_def)
            response = workspace_api.update_workspace_spark_settings(
                args, updated_spark_settings_def
            )
        # Update workspace
        else:
            response = workspace_api.update_workspace(args, update_workspace_payload)

        if response.status_code == 200:
            # Update mem_store
            workspace._name = name_description_properties["displayName"]
            utils_mem_store.upsert_workspace_to_cache(workspace)

            utils_ui.print_done("Workspace updated")


# Virtual Workspace Items
def _set_virtual_ws_item(virtual_ws_item: VirtualWorkspaceItem, args):

    match virtual_ws_item.get_item_type():
        case VirtualWorkspaceItemType.CAPACITY:
            _set_capacity(virtual_ws_item, args)
        case VirtualWorkspaceItemType.DOMAIN:
            _set_domain(virtual_ws_item, args)
        case VirtualWorkspaceItemType.CONNECTION:
            _set_connection(virtual_ws_item, args)
        case VirtualWorkspaceItemType.GATEWAY:
            _set_gateway(virtual_ws_item, args)
        case _ as x:
            raise CustomError(
                f"{str(x)} not supported", fab_constant.ERROR_NOT_SUPPORTED
            )


# Virtual Workspace Items - Capacity
def _set_capacity(virtual_ws_item: VirtualWorkspaceItem, args):

    fs._check_fabric_capacity(virtual_ws_item)
    fs.fill_capacity_args(virtual_ws_item, args)

    query = args.query

    utils_set.validate_expression(query, JMESPATH_UPDATE_CAPACITIES)

    fab_logger.log_warning("Modifying properties may lead to unintended consequences")

    if args.force or utils_ui.prompt_confirm():

        args.verbose = True
        args.output = None
        vwsi_capacity_def = fs_get._get_capacity(virtual_ws_item, args, debug=False)

        json_payload, updated_def = utils_set.update_fabric_element(
            vwsi_capacity_def, query, args.input, decode_encode=False
        )

        def _prep_for_updated_def(data):
            data.pop("id", None)
            data.pop("type", None)
            data.pop("name", None)
            data.pop("tags", None)
            data.pop("fabricId", None)
            return json.dumps(data, indent=4)

        capacity_update_def = _prep_for_updated_def(updated_def)

        utils_ui.print_grey(
            f"Setting new property for '{virtual_ws_item.get_name()}'..."
        )
        response = capacity_api.update_capacity(args, capacity_update_def)

        if response.status_code == 200:
            utils_ui.print_done("Capacity updated")


# Virtual Workspace Items - Connection
def _set_connection(connection: VirtualWorkspaceItem, args):
    query = args.query

    utils_set.validate_expression(query, JMESPATH_UPDATE_CONNECTIONS)

    fab_logger.log_warning("Modifying properties may lead to unintended consequences")

    if args.force or utils_ui.prompt_confirm():

        args.verbose = True
        args.output = None
        vwsi_connection_def = fs_get._get_connection(connection, args, debug=False)

        json_payload, updated_def = utils_set.update_fabric_element(
            vwsi_connection_def, query, args.input, decode_encode=False
        )

        def _prep_for_updated_def(data):
            data.pop("id", None)  # Remove 'id' if it exists
            data.pop("gatewayId", None)  # Remove 'type' if it exists
            data.pop(
                "connectionDetails", None
            )  # Remove 'connectionDetails' if it exists
            return json.dumps(data, indent=4)

        connection_update_def = _prep_for_updated_def(updated_def)

        args.id = connection.get_id()
        utils_ui.print_grey(f"Setting new property for '{connection.get_name()}'...")
        response = connection_api.update_connection(args, connection_update_def)

        if response.status_code == 200:
            # Update mem_store
            connection._name = updated_def["displayName"]
            utils_mem_store.upsert_connection_to_cache(connection)

            utils_ui.print_done("Connection updated")


# Virtual Workspace Items - Gateway
def _set_gateway(gateway: VirtualWorkspaceItem, args):
    query = args.query

    utils_set.validate_expression(query, JMESPATH_UPDATE_GATEWAYS)

    fab_logger.log_warning("Modifying properties may lead to unintended consequences")

    if args.force or utils_ui.prompt_confirm():

        args.verbose = True
        args.output = None
        vwsi_gateway_def = fs_get._get_gateway(gateway, args, debug=False)

        json_payload, updated_def = utils_set.update_fabric_element(
            vwsi_gateway_def, query, args.input, decode_encode=False
        )

        def _prep_for_updated_def(data):
            data.pop("id", None)
            # numberOfMemberGateways is supported only for VirtualNetwork type (reason for the whole match statement)
            match data.get("type"):
                case "OnPremises":
                    data.pop("numberOfMemberGateways", None)
                    data.pop("publicKey", None)
                    data.pop("version", None)
                case "VirtualNetwork":
                    data.pop("virtualNetworkAzureResource", None)
                case _:
                    raise CustomError(
                        f"Set Operation on Gateway type '{data.get('type')}' not supported",
                        fab_constant.ERROR_NOT_SUPPORTED,
                    )
            # Casting to int if the value is a string and present
            if isinstance(data.get("inactivityMinutesBeforeSleep", 0), str):
                data["inactivityMinutesBeforeSleep"] = int(
                    data["inactivityMinutesBeforeSleep"]
                )
            if isinstance(data.get("numberOfMemberGateways", 0), str):
                data["numberOfMemberGateways"] = int(data["numberOfMemberGateways"])

            return json.dumps(data, indent=4)

        gateway_update_def = _prep_for_updated_def(updated_def)

        args.id = gateway.get_id()
        utils_ui.print_grey(f"Setting new property for '{gateway.get_name()}'...")
        response = gateways_api.update_gateway(args, gateway_update_def)

        if response.status_code == 200:
            # Update mem_store
            gateway._name = updated_def["displayName"]
            utils_mem_store.upsert_gateway_to_cache(gateway)
            utils_ui.print_done("Gateway updated")


# Virtual Workspace Items - Domain
def _set_domain(virtual_ws_item: VirtualWorkspaceItem, args):
    query = args.query

    utils_set.validate_expression(query, JMESPATH_UPDATE_DOMAINS)

    fab_logger.log_warning("Modifying properties may lead to unintended consequences")

    if args.force or utils_ui.prompt_confirm():

        args.verbose = True
        args.output = None
        vwsi_domain_def = fs_get._get_domain(virtual_ws_item, args, debug=False)

        _, updated_def = utils_set.update_fabric_element(
            vwsi_domain_def, query, args.input, decode_encode=False
        )

        def _prep_for_updated_def(data):
            data.pop("id", None)  # Remove 'id' if it exists
            data.pop("type", None)  # Remove 'type' if it exists
            data.pop("name", None)  # Remove 'name' if it exists
            data.pop("tags", None)  # Remove 'tags' if it exists
            return json.dumps(data, indent=4)

        domain_update_def = _prep_for_updated_def(updated_def)
        args.name = virtual_ws_item.get_short_name()
        args.id = virtual_ws_item.get_id()

        utils_ui.print_grey(
            f"Setting new property for '{virtual_ws_item.get_name()}'..."
        )
        response = domain_api.update_domain(args, domain_update_def)

        if response.status_code == 200:
            # Update mem_store
            new_domain_name = updated_def["displayName"]
            virtual_ws_item._name = new_domain_name
            utils_mem_store.upsert_domain_to_cache(virtual_ws_item)

            utils_ui.print_done("Domain updated")


# Items
def _set_item(item: Item, args):

    force = args.force
    query = args.query

    utils_set.validate_expression(query, item.get_mutable_properties())

    # Get item
    args.output = None
    args.verbose = True
    item_def = fs_get._get_item(item, args, debug=False, decode=False)

    fab_logger.log_warning(
        "Modifying properties may lead to unintended consequences",
        args.command_path,
    )

    if force or utils_ui.prompt_confirm():

        query_value = item.get_property_value(query)

        # Update item
        json_payload, updated_def = utils_set.update_fabric_element(
            item_def, query_value, args.input, decode_encode=True
        )

        # Separate definition + displayName and description item properties
        definition_base64_to_update, name_description_properties = (
            utils_set.extract_json_schema(updated_def)
        )

        args.ws_id = item.get_workspace_id()
        args.id = item.get_id()
        update_item_definition_payload = json.dumps(definition_base64_to_update)
        update_item_payload = json.dumps(name_description_properties)

        utils_ui.print_grey(f"Setting new property for '{item.get_name()}'...")
        item_api.update_item(args, update_item_payload)

        try:
            if query_value.startswith("definition") and item.check_command_support(
                Command.FS_EXPORT
            ):
                item_api.update_item_definition(args, update_item_definition_payload)
        except Exception as e:
            utils_ui.print_grey(
                "Item supports only updating displayName or description, not definition",
            )

        # Update mem_store
        new_item_name = name_description_properties["displayName"]
        item._name = new_item_name
        utils_mem_store.upsert_item_to_cache(item)

        utils_ui.print_done("Item updated")


# Virtual Items
def _set_virtual_item(virtual_item: VirtualItem, args):

    match virtual_item.get_item_type():
        case VirtualItemType.SPARK_POOL:
            _set_spark_pool(virtual_item, args)
        case _ as x:
            raise CustomError(
                f"{str(x)} not supported", fab_constant.ERROR_NOT_SUPPORTED
            )


# Virtual Items - Spark Pool
def _set_spark_pool(virtual_item: VirtualItem, args):

    query = args.query

    utils_set.validate_expression(query, JMESPATH_UPDATE_SPARKPOOL)

    fab_logger.log_warning("Modifying properties may lead to unintended consequences")

    if args.force or utils_ui.prompt_confirm():

        args.verbose = True
        args.output = None
        vi_spark_pool_def = fs_get._get_spark_pool(virtual_item, args, debug=False)

        json_payload, updated_def = utils_set.update_fabric_element(
            vi_spark_pool_def, query, args.input, decode_encode=False
        )

        def _prep_for_updated_def(data):
            data.pop("id", None)  # Remove 'id' if it exists
            data.pop("type", None)  # Remove 'type' if it exists
            return json.dumps(data, indent=4)

        spark_pool_update_def = _prep_for_updated_def(updated_def)

        args.ws_id = virtual_item.get_workspace_id()
        args.id = virtual_item.get_id()
        utils_ui.print_grey(f"Setting new property for '{virtual_item.get_name()}'...")
        response = sparkpool_api.update_spark_pool(args, spark_pool_update_def)

        if response.status_code == 200:
            # Update mem_store
            virtual_item._name = updated_def["name"]
            utils_mem_store.upsert_spark_pool_to_cache(virtual_item)

            utils_ui.print_done("Spark Pool updated")


# OneLake - Shortcut
def _set_shortcut(onelake: OneLakeItem, args):

    query = args.query

    utils_set.validate_expression(query, JMESPATH_UPDATE_SHORTCUT)

    # Get shortcut
    args.output = None
    args.verbose = True
    shortcut_def = fs_get._get_shortcut(onelake, args, debug=False)
    current_name = shortcut_def.get("name", "")

    fab_logger.log_warning(
        "Modifying properties may lead to unintended consequences",
    )

    if args.force or utils_ui.prompt_confirm():

        # Read new values from the user and retrieve updated shortcut definition with the new values.
        _, updated_def = utils_set.update_fabric_element(
            shortcut_def, query, args.input, decode_encode=False
        )

        # Check if the new name matches the existing name
        new_name = updated_def.get("name", "")
        if new_name == current_name:
            fab_logger.log_warning(
                "The new name matches the existing name. No changes will be made",
                args.command_path,
            )
            return

        # Remove the key-value pair where the key is "target.type"
        if "target" in updated_def and "type" in updated_def["target"]:
            del updated_def["target"]["type"]
        json_payload = updated_def

        # Create a new shortcut with the updated values
        args.shortcutConflictPolicy = "Abort"
        shortcut_api.create_shortcut(args, json_payload)

        # Delete the old shortcut
        fs_rm._rm_onelake(onelake, args, force_delete=True, debug=False)
        utils_ui.print_done("Shortcut updated")
