import os

from fabric_cli.client import fab_api_item as item_api
from fabric_cli.core import fab_constant, fab_logger
from fabric_cli.core.fab_commands import Command
from fabric_cli.core.fab_hiearchy import FabricElement, Item, Workspace
from fabric_cli.core.fab_types import ItemType, definition_format_mapping
from fabric_cli.utils import fab_mem_store as utils_mem_store
from fabric_cli.utils import fab_storage as utils_storage
from fabric_cli.utils import fab_ui as utils_ui
from fabric_cli.utils import fab_util as utils
from fabric_cli.utils import fab_cmd_export_utils as utils_export
from fabric_cli.utils.fab_custom_exception import CustomError


def exec_command(args, context: FabricElement):

    args.output = utils.process_nargs(args.output)

    if isinstance(context, Workspace):
        _export_workspace_items(context, args)
    elif isinstance(context, Item):
        _export_item(context, args)


# Workspace Items (not workspace itself, multi-item selection)
def _export_workspace_items(workspace: Workspace, args):

    ws_items = utils_mem_store.get_workspace_items(workspace)

    if not ws_items:
        fab_logger.log_warning("Your workspace is empty", args.command_path)
        return

    supported_items = []
    for item in ws_items:
        try:
            if item.check_command_support(Command.FS_EXPORT):
                supported_items.append(item)
        except Exception as e:
            pass

    if not supported_items:
        raise CustomError(
            "Export not possible. Existing items cannot be imported/exported",
            fab_constant.ERROR_NOT_SUPPORTED,
        )

    # Add path validation before item selection
    export_path = utils_storage.get_export_path(args.output)

    selected_items = utils_ui.prompt_select_items(
        "Select the items to export:",
        [item.get_name() for item in supported_items],
    )

    if selected_items:
        utils_ui.print_grey("\n".join(selected_items))
        utils_ui.print_grey("------------------------------")
        filtered_items = [
            item for item in supported_items if item.get_name() in selected_items
        ]

        if args.force or utils_ui.prompt_confirm():
            successful_exports = 0

            for item in filtered_items:
                args.force = True  # Already confirmed for workspace
                if _export_item(item, args):
                    successful_exports = successful_exports + 1
            utils_ui.print("")
            utils_ui.print_done(f"{successful_exports} items exported successfully")


# Items
def _export_item(item: Item, args, do_export=True, decode=True, item_uri=False):

    if not item.check_command_support(Command.FS_EXPORT):
        raise CustomError(
            f"'{item.get_name()}' not supported for import/export",
            fab_constant.ERROR_NOT_SUPPORTED,
        )

    if args.force or utils_ui.prompt_confirm():
        workspace_id = item.get_workspace_id()
        item_id = item.get_id()
        item_type = item.get_item_type()

        args.from_path = item.get_path().strip("/")
        args.ws_id, args.id, args.item_type = workspace_id, item_id, str(item_type)
        args.format = definition_format_mapping.get(item_type, "")

        item_def = item_api.get_item_withdefinition(args, item_uri)

        if decode:
            item_def = utils_export.decode_payload(item_def)
            if item.get_item_type() == ItemType.NOTEBOOK:
                tags_to_clean = ["outputs"]
                item_def = utils_export.clean_notebook_cells(item_def, tags_to_clean)

        if do_export:
            export_path = utils_storage.get_export_path(args.output)

            original_path = export_path["path"]
            export_path["path"] = f"{original_path}/{item.get_name()}"
            _to_path = export_path["path"]

            if export_path["type"] == "local":
                os.makedirs(_to_path, exist_ok=True)
            utils_ui.print_grey(f"Exporting '{args.from_path}' → '{_to_path}'...")
            utils_export.export_json_parts(item_def["definition"], export_path)
            utils_ui.print_done(f"'{item.get_full_name()}' exported")

        return item_def
