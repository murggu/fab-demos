import json

from fabric_cli.api import fab_api_request as api_request
from fabric_cli.core import fab_constant
from fabric_cli.utils import fab_util as utils
from fabric_cli.utils.fab_custom_exception import CustomError
from fabric_cli.utils.fab_error_parser import handle_custom_exceptions
from fabric_cli.utils.fab_util import set_command_context


@handle_custom_exceptions()
@set_command_context()
def request_command(args):
    args.headers = utils.process_nargs(args.headers)
    args.params = utils.process_nargs(args.params)
    args.endpoint = utils.process_nargs(args.endpoint)

    _parse_config_args(args)
    _build_query_parameters(args)
    _build_headers(args)
    api_request.exec_command(args)


# Utils
def _build_key_value_pairs(input_str, error_message):
    result = {}
    if input_str:
        try:
            for pair in input_str.split(","):
                key, value = map(str.strip, pair.split("=", 1))
                result[key] = value
        except ValueError:
            raise CustomError(error_message)
    return result


def _build_query_parameters(args):
    args.request_params = _build_key_value_pairs(
        args.params,
        "Invalid format for query parameters. Use key=value pairs separated by commas.",
    )


def _build_headers(args):
    args.headers = _build_key_value_pairs(
        args.headers,
        "Invalid format for headers. Use key=value pairs separated by commas.",
    )


def _parse_config_args(args):
    # Helper function to parse the execution data into a correct json format
    if not args.input:
        return

    # Normalize the content array to a single string without quotes
    normalized_content = " ".join(args.input).strip("\"'")

    if normalized_content.startswith("{") and normalized_content.endswith("}"):
        configuration = json.loads(normalized_content)
    else:
        # Validate that the content is a valid file path
        try:
            with open(normalized_content, "r") as file:
                configuration = json.load(file)
        except Exception as e:
            raise CustomError(
                f"Invalid JSON content: {normalized_content}. Error: {str(e)}",
                fab_constant.ERROR_INVALID_JSON,
            )
    args.input = configuration
