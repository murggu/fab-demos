from fabric_cli.client import fab_api_client as fabric_api
from fabric_cli.utils import fab_ui as utils_ui


def exec_command(args):
    args.raw_response = True
    args.uri = args.endpoint
    if args.input is not None:
        response = fabric_api.do_request(args, json=args.input)
    else:
        response = fabric_api.do_request(args)
    utils_ui.print_api_response(response, headers=args.show_headers)
