import json

from fabric_cli.client import fab_api_connection as api_connections
from fabric_cli.client import fab_api_gateway as api_gateways
from fabric_cli.client import fab_api_item as api_items
from fabric_cli.client import fab_api_onelake as api_onelake
from fabric_cli.client import fab_api_workspace as api_workspaces
from fabric_cli.core import fab_constant, fab_logger
from fabric_cli.core.fab_hiearchy import (
    FabricElement,
    Item,
    OneLakeItem,
    VirtualWorkspaceItem,
    Workspace,
)
from fabric_cli.core.fab_types import ItemType, VirtualWorkspaceItemType
from fabric_cli.utils import fab_ui as utils_ui
from fabric_cli.utils.fab_custom_exception import CustomError, FabricAPIError


def exec_command(args, context: FabricElement):

    if isinstance(context, Workspace):
        fab_logger.log_warning(fab_constant.WARNING_FABRIC_ADMIN_ROLE)
        _ls_acls_workspace(context, args)
    elif isinstance(context, Item):
        fab_logger.log_warning(fab_constant.WARNING_FABRIC_ADMIN_ROLE)
        _ls_acls_item(context, args)
    elif isinstance(context, VirtualWorkspaceItem):
        fab_logger.log_warning(fab_constant.WARNING_FABRIC_ADMIN_ROLE)
        _ls_acls_vwitem(context, args)
    elif (
        isinstance(context, OneLakeItem)
        and context.get_parent().get_item_type() == ItemType.LAKEHOUSE
    ):
        fab_logger.log_warning(fab_constant.WARNING_ONELAKE_RBAC_ENABLED)
        _ls_acls_onelake(context, args)


# Workspaces
def _ls_acls_workspace(workspace: Workspace, args):

    show_all = bool(args.long)

    args.ws_id = workspace.get_id()
    response = api_workspaces.acl_list_from_workspace(args)

    if response.status_code == 200:
        data = json.loads(response.text)
        ws_acls = data["value"]

        if ws_acls:
            sorted_acls = []

            for acl in ws_acls:
                principal = acl.get("principal", {})
                user_details = principal.get("userDetails")
                service_principal_details = principal.get("servicePrincipalDetails")
                group_details = principal.get("groupDetails")

                identity = None
                if user_details:
                    identity = user_details.get("userPrincipalName")
                elif service_principal_details:
                    identity = service_principal_details.get("aadAppId")
                elif group_details:
                    identity = principal.get("displayName")

                sorted_acls.append(
                    {
                        "name": principal.get("displayName", "Unknown"),
                        "type": principal.get("type", "Unknown"),
                        "identity": identity,
                        "objectId": acl.get("id", "Unknown"),
                        "acl": acl.get("role", "Unknown"),
                    }
                )
            sorted_acls = sorted(sorted_acls, key=lambda acl: acl["acl"])
            columns = (
                ["acl", "identity", "type", "objectId", "name"]
                if show_all
                else ["acl", "identity", "type"]
            )
            utils_ui.print_entries_unix_style(sorted_acls, columns, header=True)


# Virtual Workspace Items
def _ls_acls_vwitem(item: VirtualWorkspaceItem, args):

    match item.get_item_type():
        case VirtualWorkspaceItemType.GATEWAY:
            _ls_acls_gateway(item, args)
        case VirtualWorkspaceItemType.CONNECTION:
            _ls_acls_connection(item, args)
        case _:
            raise CustomError("Not supported", fab_constant.ERROR_NOT_SUPPORTED)


# Virtual Workspace Items - Gateway
def _ls_acls_gateway(gateway: VirtualWorkspaceItem, args):
    show_all = bool(args.long)
    args.gw_id = gateway.get_id()
    response = api_gateways.acl_list_from_gateway(args)

    if response.status_code == 200:
        data = json.loads(response.text)
        access_details = data["value"]

        if access_details:
            sorted_acls = []

            for acl in access_details:
                sorted_acls.append(
                    {
                        "id": acl["id"],
                        "role": acl["role"],
                        "principalId": acl["principal"]["id"],
                        "principalType": acl["principal"]["type"],
                    }
                )

            sorted_acls = sorted(sorted_acls, key=lambda acl: acl["role"])
            columns = (
                ["id", "role", "principalId", "principalType"]
                if show_all
                else ["role", "principalId", "principalType"]
            )
            utils_ui.print_entries_unix_style(sorted_acls, columns, header=True)


# Virtual Workspace Items - Connection
def _ls_acls_connection(connection: VirtualWorkspaceItem, args):
    show_all = bool(args.long)
    args.con_id = connection.get_id()
    response = api_connections.acl_list_from_connection(args)

    if response.status_code == 200:
        data = json.loads(response.text)
        access_details = data["value"]

        if access_details:
            sorted_acls = []

            for acl in access_details:
                sorted_acls.append(
                    {
                        "id": acl["id"],
                        "role": acl["role"],
                        "principalId": acl["principal"]["id"],
                        "principalType": acl["principal"]["type"],
                    }
                )

            sorted_acls = sorted(sorted_acls, key=lambda acl: acl["role"])
            columns = (
                ["id", "role", "principalId", "principalType"]
                if show_all
                else ["role", "principalId", "principalType"]
            )
            utils_ui.print_entries_unix_style(sorted_acls, columns, header=True)


# Items
def _ls_acls_item(item: Item, args):

    show_all = bool(args.long)

    args.ws_id = item.get_workspace_id()
    args.id = item.get_id()
    response = api_items.acl_list_from_item(args)

    if response.status_code == 200:
        data = json.loads(response.text)
        access_details = data["accessDetails"]

        if access_details:
            sorted_acls = []

            for acl in access_details:
                principal = acl["principal"]
                itemAccessDetails = acl["itemAccessDetails"]

                identity = None
                if "userDetails" in principal:
                    identity = principal["userDetails"].get("userPrincipalName")
                elif "servicePrincipalDetails" in principal:
                    identity = principal["servicePrincipalDetails"].get("aadAppId")
                elif "groupDetails" in principal:
                    identity = principal["groupDetails"].get("groupType")

                sorted_acls.append(
                    {
                        "name": principal["displayName"],
                        "type": principal["type"],
                        "identity": identity,
                        "id": principal["id"],
                        "acl": itemAccessDetails["permissions"],
                    }
                )

            sorted_acls = sorted(sorted_acls, key=lambda acl: acl["acl"])
            columns = (
                ["acl", "identity", "type", "id", "name"]
                if show_all
                else ["acl", "identity", "type"]
            )
            utils_ui.print_entries_unix_style(sorted_acls, columns, header=True)


# OneLake - Lakehouse
def _ls_acls_onelake(context: OneLakeItem, args):

    show_all = bool(args.long)
    workspace_name = context.get_workspace_name()
    workspace_id = context.get_workspace_id()
    item_id = context.get_item_id()
    item_name = context.get_parent().get_name()

    args.ws_id = workspace_id
    args.id = item_id

    try:
        response = api_onelake.acl_list_data_access_roles(args)

        if response.status_code == 200:
            data = json.loads(response.text)
            access_details = data["value"]

            if access_details:
                sorted_acls = []

            for rbac in access_details:
                name = rbac["name"]
                decisionRules = rbac["decisionRules"]

                # Safely access "microsoftEntraMembers" and "fabricItemMembers"
                microsoft_en_a_members = [
                    {"identity": member["objectId"], "type": "microsoftEntraMember"}
                    for member in rbac["members"].get("microsoftEntraMembers", [])
                ]
                fabric_item_members = [
                    {"identity": member["sourcePath"], "type": "fabricItemMember"}
                    for member in rbac["members"].get("fabricItemMembers", [])
                ]

                # Append the members to sorted_acls
                for member in microsoft_en_a_members:
                    sorted_acls.append(
                        {
                            "identity": member["identity"],
                            "details": decisionRules,
                            "acl": name,
                            "type": member[
                                "type"
                            ],  # Add the type for microsoftEntraMember
                        }
                    )

                for member in fabric_item_members:
                    sorted_acls.append(
                        {
                            "identity": member["identity"],
                            "details": decisionRules,
                            "acl": name,
                            "type": member["type"],  # Add the type for fabricItemMember
                        }
                    )

            sorted_acls = sorted(sorted_acls, key=lambda acl: acl["acl"])
            columns = (
                ["acl", "identity", "type", "details"]
                if show_all
                else ["acl", "identity", "type"]
            )
            utils_ui.print_entries_unix_style(sorted_acls, columns, header=True)

    except FabricAPIError as e:
        if e.status_code == "BadRequest":
            fab_logger.log_error(
                f"Universal security disabled in '{item_name}'",
                f"{args.command_path}",
            )
            utils_ui.print_grey(
                f"→ Run 'open /{workspace_name}/{item_name}' and enable it"
            )
        else:
            raise
