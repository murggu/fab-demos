from fabric_cli.core import fab_constant, fab_state_config
from fabric_cli.utils import fab_ui as utils_ui
from fabric_cli.utils.fab_custom_exception import CustomError


def exec_command(args):
    key = args.key.lower()
    if key not in fab_constant.CONFIG_KEYS:
        raise CustomError(
            f"'{key}' is not a known configuration key",
            fab_constant.ERROR_INVALID_INPUT,
        )
    else:
        value = fab_state_config.get_config(key)
        if value:
            utils_ui.print_grey(value)
