# Endpoints
API_ENDPOINT_FABRIC = "api.fabric.microsoft.com"
API_VERSION_FABRIC = "v1"
API_ENDPOINT_ONELAKE = "onelake.dfs.fabric.microsoft.com"
API_ENDPOINT_AZURE = "management.azure.com"
API_ENDPOINT_POWER_BI = "api.powerbi.com/v1.0/myorg"

API_USER_AGENT = "ms-fabric-cli"
API_USER_AGENT_TEST = "ms-fabric-cli-test"
WEB_URI = "https://app.powerbi.com/groups"

# Versioning
FAB_VERSION = "0.1.6"  # change pyproject.toml version too, this must be aligned

# Scopes
SCOPE_FABRIC_DEFAULT = ["https://analysis.windows.net/powerbi/api/.default"]
SCOPE_ONELAKE_DEFAULT = ["https://storage.azure.com/.default"]
SCOPE_AZURE_DEFAULT = ["https://management.azure.com/.default"]

# Auth
AUTH_DEFAULT_AUTHORITY = "https://login.microsoftonline.com/common"
AUTH_DEFAULT_CLIENT_ID = "1950a258-227b-4e31-a9cf-717495945fc2"
AUTH_TENANT_AUTHORITY = "https://login.microsoftonline.com/"

# Env variables
FAB_TOKEN = "fab_token"
FAB_TOKEN_ONELAKE = "fab_token_onelake"
FAB_TOKEN_AZURE = "fab_token_azure"
FAB_SPN_CLIENT_ID = "fab_spn_client_id"
FAB_SPN_CLIENT_SECRET = "fab_spn_client_secret"
FAB_TENANT_ID = "fab_tenant_id"

FAB_REFRESH_TOKEN = "fab_refresh_token"
FAB_AUTHORITY = "fab_authority"
FAB_AUTH_MODE = "fab_auth_mode"

AUTH_KEYS = {
    FAB_TENANT_ID: [],
    FAB_AUTHORITY: [],
    FAB_AUTH_MODE: ["user", "service_principal"],
}

# Other constants
FAB_DEFAULT_OPEN_EXPERIENCE_FABRIC = "fabric-developer"
FAB_DEFAULT_OPEN_EXPERIENCE_POWERBI = "power-bi"
FAB_DEFAULT_CAPACITY_ID = "fab_default_capacity_id"
FAB_MODE_INTERACTIVE = "interactive"
FAB_MODE_COMMANDLINE = "command_line"

# CLI settings
FAB_MODE = "fab_mode"
FAB_DEBUG_ENABLED = "fab_debug_enabled"
FAB_CACHE_ENABLED = "fab_cache_enabled"
FAB_SHOW_HIDDEN = "fab_show_hidden"
FAB_ENCRYPTION_FALLBACK_ENABLED = "fab_encryption_fallback_enabled"
FAB_LOCAL_DEFINITION_LABELS = "fab_local_definition_labels"
FAB_LOCAL_COMMAND_YAML = "fab_local_command_yaml"
FAB_DEFAULT_OPEN_EXPERIENCE = "fab_default_open_experience"
FAB_DEFAULT_CAPACITY = "fab_default_capacity"
FAB_DEFAULT_AZ_SUBSCRIPTION_ID = "fab_default_az_subscription_id"
FAB_DEFAULT_AZ_RESOURCE_GROUP = "fab_default_az_resource_group"
FAB_DEFAULT_AZ_LOCATION = "fab_default_az_location"
FAB_DEFAULT_AZ_ADMIN = "fab_default_az_admin"
# FAB_OUTPUT = "fab_output"

CONFIG_KEYS = {
    FAB_MODE: [FAB_MODE_INTERACTIVE, FAB_MODE_COMMANDLINE],
    # FAB_OUTPUT: ["json", "markdown", "plain"],
    FAB_DEBUG_ENABLED: ["false", "true"],
    FAB_CACHE_ENABLED: ["false", "true"],
    FAB_SHOW_HIDDEN: ["false", "true"],
    FAB_ENCRYPTION_FALLBACK_ENABLED: ["false", "true"],
    FAB_LOCAL_DEFINITION_LABELS: [],
    FAB_LOCAL_COMMAND_YAML: [],
    FAB_DEFAULT_OPEN_EXPERIENCE: ["fabric", "powerbi"],
    FAB_DEFAULT_CAPACITY: [],
    FAB_DEFAULT_AZ_SUBSCRIPTION_ID: [],
    FAB_DEFAULT_AZ_RESOURCE_GROUP: [],
    FAB_DEFAULT_AZ_LOCATION: [],
    FAB_DEFAULT_AZ_ADMIN: [],
    # Add more keys and their respective allowed values as needed
}

# Command descriptions
COMMAND_AUTH_DESCRIPTION = "Authenticate fab with Fabric."
COMMAND_FS_DESCRIPTION = "Workspace, item and file system operations."
COMMAND_JOBS_DESCRIPTION = "Manage tasks and jobs."
COMMAND_TABLES_DESCRIPTION = "Manage tables."
COMMAND_SHORTCUTS_DESCRIPTION = "Manage shorcuts."
COMMAND_ACLS_DESCRIPTION = "Manage permissions [admin]."
COMMAND_CONFIG_DESCRIPTION = "Manage configuration settings."
COMMAND_API_DESCRIPTION = "Make an authenticated API request."
COMMAND_EXTENSIONS_DESCRIPTION = "Manage extensions."
COMMAND_LABELS_DESCRIPTION = "Manage sensitivity labels [admin]."
COMMAND_CAPACITIES_DESCRIPTION = "(tenant) Manage capacities [admin]."
COMMAND_CONNECTIONS_DESCRIPTION = "(tenant) Manage connections."
COMMAND_DOMAINS_DESCRIPTION = "(tenant) Manage domains [admin]."
COMMAND_EXTERNAL_DATA_SHARES_DESCRIPTION = (
    "(tenant) Manage external data shares [admin]."
)
COMMAND_GATEWAYS_DESCRIPTION = "(tenant) Manage gateways."
COMMAND_FOLDERS_DESCRIPTION = "(workspace) Manage folders."
COMMAND_MANAGED_IDENTITIES_DESCRIPTION = "(workspace) Manage managed identities."
COMMAND_MANAGED_PRIVATE_ENDPOINTS_DESCRIPTION = (
    "(workspace) Manage managed private endpoints."
)
COMMAND_SPARK_POOLS_DESCRIPTION = "(workspace) Manage Apache Spark pools."
COMMAND_VARIABLES_DESCRIPTION = "(workspace) Manage variables."
COMMAND_DESCRIBE_DESCRIPTION = "Show commands supported by each Fabric element or path."

# Info
INFO_EXISTS_TRUE = "true"
INFO_EXISTS_FALSE = "false"
INFO_FEATURE_NOT_SUPPORTED = "Feature is not supported yet"

# Warnings
WARNING_INVALID_ELEMENT_TYPE = "Invalid element type"
WARNING_INVALID_WORKSPACE_NAME = "Invalid workspace name"
WARNING_INVALID_WORKSPACE_TYPE = "Invalid workspace type"
WARNING_INVALID_ITEM_NAME = "Invalid item name"
WARNING_INVALID_ITEM_TYPE = "Invalid item type"
WARNING_NOT_SUPPORTED_ITEM = "Not supported in this item type"
WARNING_DIFFERENT_ITEM_TYPES = "Different item types, review"
WARNING_INVALID_PATHS = (
    "Source and destination must be of the same type. Check your paths"
)
WARNING_INVALID_SPECIAL_CHARACTERS = (
    "Special caracters not supported for this item type"
)
WARNING_INVALID_LS_ONELAKE = "No more subdirectories supported for this item"
WARNING_MKDIR_INVALID_ONELAKE = "Invalid paths. Only supported within /Files"
WARNING_OPERATION_NO_RESULT = "Long Running Operation returned no result"
WARNING_FABRIC_ADMIN_ROLE = "Requires Fabric admin role"
WARNING_ONELAKE_RBAC_ENABLED = "Requires data access roles enabled"
WARNING_UNSUPPORTED_COMMAND = "Unsupported command"
WARNING_NON_FABRIC_CAPACITY = "Not a Fabric capacity"
WARNING_ONLY_SUPPORTED_WITHIN_LAKEHOUSE = "Only supported within Lakehouse"
WARNING_ONLY_SUPPORTED_WITHIN_FILES_AND_TABLES = (
    "Only supported within Files/ and Tables/"
)

# Error codes
ERROR_NOT_FOUND = "NotFound"
ERROR_UNAUTHORIZED = "Unauthorized"
ERROR_FORBIDDEN = "Forbidden"
ERROR_NOT_RUNNABLE = "NotRunnable"
ERROR_INVALID_PATH = "InvalidPath"
ERROR_OPERATION_FAILED = "LongRunningOperationFailed"
ERROR_OPERATION_CANCELLED = "LongRunningOperationCancelled"
ERROR_INVALID_JSON = "InvalidJson"
ERROR_AUTHENTICATION_FAILED = "AuthenticationFailed"
ERROR_INVALID_OPERATION = "InvalidOperation"
ERROR_NOT_SUPPORTED = "NotSupported"
ERROR_INVALID_INPUT = "InvalidInput"
ERROR_ALREADY_EXISTS = "AlreadyExists"
ERROR_MAX_RETRIES_EXCEEDED = "MaxRetriesExceeded"
ERROR_ALREADY_RUNNING = "AlreadyRunning"
ERROR_NOT_RUNNING = "NotRunning"

# Contextual commands
OS_COMMANDS = {
    "rm": {"windows": "del", "unix": "rm"},
    "ls": {"windows": "dir", "unix": "ls"},
    "mv": {"windows": "move", "unix": "mv"},
    "cp": {"windows": "copy", "unix": "cp"},
    "ln": {
        "windows": "mklink",
        "unix": "ln",
    },
    "clear": {
        "windows": "cls",
        "unix": "clear",
    },
}

# DEBUG
DEBUG = False


# Platform metadata
ITEM_METADATA_PROPERTIES = {
    "id",
    "type",
    "displayName",
    "description",
    "workspaceId",
    "folderId",
}
